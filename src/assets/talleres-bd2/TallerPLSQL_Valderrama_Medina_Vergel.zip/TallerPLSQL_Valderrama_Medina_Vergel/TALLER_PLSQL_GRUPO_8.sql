--------------------------------------------------------------------------------
-- UNIVERSIDAD EL BOSQUE — INGENIERIA DE SISTEMAS
-- Asignatura: Bases de Datos 2
-- Docente: Ing., Esp., M.Ed. Christian Felipe Duarte
--
-- TALLER PL/SQL — PLANTILLA DE ENTREGA
--
-- GRUPO No.: ____
-- INTEGRANTES: 1) Sergio Andres Valderrama Veléz
--              2) Liseth Natalia Vergel Rodriguez
--              3) Federico Medina Ospina
-- FECHA DE ENTREGA: 03/10/2026
--------------------------------------------------------------------------------
--
-- COMO TRABAJAR
--   1. Ejecute primero, completo, el script 01_esquema_inventario.sql
--   2. Desarrolle cada punto en la seccion correspondiente de este archivo
--   3. No borre los encabezados de cada ejercicio ni cambie los nombres de los
--      objetos solicitados. La revision los busca por nombre: un objeto correcto
--      con otro nombre se califica como no entregado.
--   4. Los esqueletos de la Parte 5 no incluyen la clausula de disparo. Definirla
--      hace parte del ejercicio, de modo que esos bloques no compilan tal como se
--      entregan.
--
-- DISTRIBUCION DEL PUNTAJE                                     Total: 50 puntos
--   Parte 1  Procedimientos almacenados .................  8 puntos
--   Parte 2  Funciones ...................................  8 puntos
--   Parte 3  Cursores .................................... 10 puntos
--   Parte 4  Manejo de excepciones .......................  9 puntos
--   Parte 5  Disparadores ................................ 10 puntos
--   Parte 6  Caso integrador .............................  5 puntos
--
-- CRITERIOS DE EVALUACION
--   Correccion tecnica ....... 40%   El objeto compila y cumple el enunciado
--   Justificacion ............ 40%   Las decisiones de diseno estan argumentadas
--   Analisis operacional ..... 20%   Se anticipa el comportamiento ante
--                                    concurrencia, volumen y error
--
--   Cada objeto debe incluir su justificacion en el espacio marcado. Un ejercicio
--   sin justificacion obtiene como maximo el 40% de su puntaje aunque funcione.
--   Una justificacion que confunde la causa con el efecto no obtiene puntaje.
--   Describir lo que hace el codigo, sin argumentar por que se eligio esa
--   construccion y no otra, equivale a no justificar.
--
-- ENTREGA
--   Este archivo renombrado como TALLER_PLSQL_GRUPO_<n>.sql, junto con un
--   documento que contenga las salidas de DBMS_OUTPUT de cada bloque ejecutado.
--   Ambos archivos deben incluir los nombres de los tres integrantes.
--
-- SUSTENTACION
--   20 minutos por grupo. Los tres integrantes deben poder explicar cualquier
--   parte del codigo, no solamente la que desarrollaron.
--------------------------------------------------------------------------------
--
-- CONVENCIONES DE ESTA ENTREGA
--
--   a) Debajo de cada objeto hay un bloque "EVIDENCIA x.y" que lo ejecuta y
--      muestra el resultado por DBMS_OUTPUT. Esas salidas son las que se
--      capturan para el PDF. Cada comentario "RESULTADO ESPERADO" indica lo que
--      debe verse partiendo del esquema recien cargado.
--   b) Los bloques de evidencia que modifican datos terminan en ROLLBACK, para
--      que cada prueba parta del estado inicial y el archivo sea reejecutable.
--      Las secuencias no se revierten con ROLLBACK (por diseno de Oracle), asi
--      que los identificadores generados pueden variar entre ejecuciones.
--   c) Ningun objeto hace COMMIT (salvo SP_REGISTRAR_ERROR, que es autonomo).
--      El limite de la transaccion lo define quien invoca; ver Parte 6.
--   d) Codigos de error propios usados en todo el taller:
--        -20010 .. -20012  SP_ANULAR_PEDIDO (definidos por el enunciado)
--        -20020            margen minimo no alcanzado (TRG_PRODUCTO_BIU_MARGEN)
--        -20030            stock insuficiente (mismo codigo en SP_AJUSTAR_STOCK,
--                          SP_VALIDAR_DESPACHO y TRG_DETALLE_AI_STOCK: una misma
--                          condicion de negocio se reporta siempre igual)
--        -20050            columna no modificable via V_STOCK_CONSOLIDADO
--        -20060 .. -20063  PKG_VENTAS.SP_FACTURAR_PEDIDO
--        -20101 .. -20105  SP_REGISTRAR_PRODUCTO
--        -20111 .. -20117  SP_AJUSTAR_STOCK
--        -20121 .. -20123  SP_CREAR_PEDIDO
--
--------------------------------------------------------------------------------

SET SERVEROUTPUT ON SIZE UNLIMITED
SET DEFINE OFF

--==============================================================================
-- PREPARACION — SINCRONIZACION DE SECUENCIAS
--==============================================================================
-- El script 01 sincroniza SEQ_PEDIDO y SEQ_MOVIMIENTO, pero no SEQ_PRODUCTO
-- (inicia en 1000, los productos van de 1001 a 1015) ni SEQ_CLIENTE (inicia en
-- 500, los clientes van de 501 a 507). Sin este paso, el segundo producto o el
-- segundo cliente creados por secuencia chocarian con la llave primaria.
-- Se usa la misma tecnica del script 01 (consumir NEXTVAL), de modo que no se
-- altera la estructura ni los datos cargados.
--------------------------------------------------------------------------------
DECLARE
    v_max NUMBER;
    v_val NUMBER;
BEGIN
    SELECT NVL(MAX(id_producto), 0) INTO v_max FROM PRODUCTO;
    LOOP
        v_val := SEQ_PRODUCTO.NEXTVAL;
        EXIT WHEN v_val >= v_max;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('SEQ_PRODUCTO sincronizada. Ultimo valor consumido: ' || v_val);

    SELECT NVL(MAX(id_cliente), 0) INTO v_max FROM CLIENTE;
    LOOP
        v_val := SEQ_CLIENTE.NEXTVAL;
        EXIT WHEN v_val >= v_max;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('SEQ_CLIENTE sincronizada.  Ultimo valor consumido: ' || v_val);
END;
/


--==============================================================================
-- PARTE 1 — PROCEDIMIENTOS ALMACENADOS                        (8 puntos / 75 min)
--==============================================================================

------------------------------------------------------------------- 1.1 (2 pts)
-- SP_REGISTRAR_PRODUCTO
-- Registra un producto nuevo. Debe asignar el identificador desde SEQ_PRODUCTO,
-- validar que el precio de venta supere el costo unitario, verificar que la
-- categoria exista y manejar el caso de codigo duplicado. Devuelve el
-- identificador generado.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) Precio > costo y existencia de la categoria se validan ANTES del INSERT
--    para devolver un codigo propio (-20102, -20103) que el cliente pueda
--    distinguir. La FK sigue siendo la garantia final: si otra sesion borra la
--    categoria entre la consulta y el INSERT, ORA-02291 impide el huerfano. La
--    validacion del SP existe por el mensaje; la FK, por la integridad.
-- 2) El codigo duplicado NO se consulta antes (SELECT COUNT ... WHERE codigo):
--    entre esa consulta y el INSERT otra sesion puede registrar el mismo codigo,
--    y ambas pasarian la validacion. Se delega en UK_PRODUCTO_CODIGO, que es
--    atomica, y se traduce DUP_VAL_ON_INDEX a -20104. Como DUP_VAL_ON_INDEX
--    tambien la lanza la PK, se distingue por el nombre de la restriccion.
-- 3) Si la PK colisiona (secuencia desincronizada, ver PREPARACION), el SP pide
--    el siguiente valor y reintenta, con tope de 50 intentos para no entrar en
--    un ciclo infinito. Asi el procedimiento no depende de que alguien recuerde
--    sincronizar la secuencia.
-- 4) El codigo se guarda en MAYUSCULAS y sin espacios: la UK distingue
--    mayusculas, de modo que 'hm-0001' y 'HM-0001' pasarian como productos
--    distintos (el problema que se demuestra en 4.1). Normalizar en la entrada
--    cierra ese duplicado logico que la restriccion no ve.
-- 5) No hay COMMIT: registrar un producto puede ser un paso de una operacion
--    mayor y el SP no sabe si es el ultimo; la transaccion la cierra quien llama.
-- Operacional: la concurrencia la resuelve el indice unico; un INSERT fallido
-- no deja rastro (atomicidad de sentencia); el costo es una fila por llamada.
--
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_PRODUCTO (
    p_codigo        IN  VARCHAR2,
    p_nombre        IN  VARCHAR2,
    p_id_categoria  IN  NUMBER,
    p_precio        IN  NUMBER,
    p_costo         IN  NUMBER,
    p_stock_minimo  IN  NUMBER DEFAULT 0,
    p_id_producto   OUT NUMBER
) IS
    c_max_intentos  CONSTANT PLS_INTEGER := 50;
    v_codigo        PRODUCTO.codigo%TYPE;
    v_existe        PLS_INTEGER;
    v_id            PRODUCTO.id_producto%TYPE;
BEGIN
    v_codigo := UPPER(TRIM(p_codigo));

    IF v_codigo IS NULL OR TRIM(p_nombre) IS NULL
       OR p_precio IS NULL OR p_costo IS NULL OR NVL(p_stock_minimo, 0) < 0 THEN
        RAISE_APPLICATION_ERROR(-20101,
            'Codigo, nombre, precio y costo son obligatorios y el stock minimo no puede ser negativo.');
    END IF;

    IF p_costo <= 0 OR p_precio <= p_costo THEN
        RAISE_APPLICATION_ERROR(-20102,
            'El precio de venta (' || p_precio || ') debe superar el costo unitario (' || p_costo || ').');
    END IF;

    SELECT COUNT(*) INTO v_existe FROM CATEGORIA WHERE id_categoria = p_id_categoria;
    IF v_existe = 0 THEN
        RAISE_APPLICATION_ERROR(-20103, 'La categoria ' || p_id_categoria || ' no existe.');
    END IF;

    FOR i IN 1 .. c_max_intentos LOOP
        v_id := SEQ_PRODUCTO.NEXTVAL;
        BEGIN
            INSERT INTO PRODUCTO (id_producto, codigo, nombre, id_categoria,
                                  precio_unitario, costo_unitario, stock_minimo, activo)
            VALUES (v_id, v_codigo, TRIM(p_nombre), p_id_categoria,
                    p_precio, p_costo, NVL(p_stock_minimo, 0), 'S');
            p_id_producto := v_id;
            RETURN;
        EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
                IF INSTR(SQLERRM, 'UK_PRODUCTO_CODIGO') > 0 THEN
                    RAISE_APPLICATION_ERROR(-20104,
                        'Ya existe un producto con el codigo ' || v_codigo || '.');
                ELSIF INSTR(SQLERRM, 'PK_PRODUCTO') = 0 THEN
                    RAISE;                -- otra restriccion unica: no se oculta
                END IF;
                -- Colision de PK: el ciclo pide el siguiente valor de la secuencia
        END;
    END LOOP;

    RAISE_APPLICATION_ERROR(-20105,
        'No se obtuvo un identificador libre tras ' || c_max_intentos || ' intentos. Revise SEQ_PRODUCTO.');
END SP_REGISTRAR_PRODUCTO;
/

-- EVIDENCIA 1.1
-- RESULTADO ESPERADO: el primero se registra (codigo guardado como FG-0100);
-- los otros cuatro se rechazan con -20104, -20104, -20102 y -20103.
DECLARE
    v_id     NUMBER;
    v_codigo PRODUCTO.codigo%TYPE;
    PROCEDURE probar (p_desc VARCHAR2, p_cod VARCHAR2, p_cat NUMBER,
                      p_precio NUMBER, p_costo NUMBER) IS
    BEGIN
        SP_REGISTRAR_PRODUCTO(p_cod, 'Producto de prueba', p_cat, p_precio, p_costo, 10, v_id);
        SELECT codigo INTO v_codigo FROM PRODUCTO WHERE id_producto = v_id;
        DBMS_OUTPUT.PUT_LINE(RPAD('OK        ' || p_desc, 45) || 'id=' || v_id || ' codigo=' || v_codigo);
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(RPAD('RECHAZADO ' || p_desc, 45) || SQLERRM);
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    probar('Producto valido (codigo en minusculas)', ' fg-0100 ', 4, 15000, 10000);
    probar('Codigo duplicado',                        'HM-0001',  1, 45000, 28000);
    probar('Codigo duplicado escrito distinto',       'hm-0001',  1, 45000, 28000);
    probar('Precio no supera el costo',               'FG-0101',  4, 10000, 10000);
    probar('Categoria inexistente',                   'FG-0102', 99, 15000, 10000);
    ROLLBACK;
END;
/

------------------------------------------------------------------- 1.2 (3 pts)
-- SP_AJUSTAR_STOCK
-- Registra una ENTRADA, SALIDA o AJUSTE de inventario sobre una bodega.
-- Debe actualizar EXISTENCIA e insertar el registro en MOVIMIENTO_INVENTARIO,
-- devolviendo el saldo resultante.
--   * Si la combinacion bodega-producto no existe y el tipo es ENTRADA, crearla
--   * Si el tipo es SALIDA y no existe la combinacion, rechazar la operacion
--   * Una SALIDA nunca puede dejar la existencia en negativo
-- Proteja la lectura de la existencia frente a modificaciones concurrentes.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) Concurrencia. La existencia se lee con SELECT ... FOR UPDATE. Sin el
--    bloqueo, dos sesiones que despachan 10 unidades de un saldo de 12 leen
--    ambas 12, ambas validan y el saldo queda en -8 (o la segunda escritura
--    pisa la primera: "lost update"). Con FOR UPDATE la segunda sesion espera a
--    que la primera termine y luego lee el saldo ya descontado.
--    Se usa WAIT 5 y no espera indefinida: si otra transaccion deja la fila
--    bloqueada (usuario que no confirma), el llamador recibe -20117 en 5 s en
--    lugar de quedar colgado. NOWAIT se descarto porque falla ante bloqueos de
--    milisegundos que son normales en operacion.
-- 2) Fila inexistente en ENTRADA: el INSERT puede competir con otra sesion que
--    crea la misma combinacion. La PK de EXISTENCIA hace que la segunda espere
--    y reciba DUP_VAL_ON_INDEX; en ese caso se relee con FOR UPDATE y se suma
--    sobre el valor de la otra sesion. No se usa MERGE porque despues hay que
--    validar el saldo y construir el movimiento con el valor anterior.
-- 3) AJUSTE. El dato cargado (movimiento 20, "Conteo fisico") solo cuadra si
--    el ajuste registra la DIFERENCIA de un conteo: 145 - 120 = 25. Por eso
--    p_cantidad en un AJUSTE es la cantidad contada (puede ser 0), la existencia
--    queda en ese valor y el movimiento registra |contado - sistema|. Como
--    MOVIMIENTO_INVENTARIO.cantidad exige > 0 y no guarda signo, el sentido
--    queda en la observacion "(+)" / "(-)"; si no hay diferencia no se registra
--    movimiento. Limitacion reconocida: el signo no es consultable por columna.
-- 4) Se rechazan bodegas inactivas (la 5): mover inventario hacia o desde una
--    bodega cerrada es un error de captura, no una operacion valida.
-- 5) Mismo codigo -20030 para "stock insuficiente" que el trigger 5.4 y 4.2,
--    para que el cliente trate igual la misma condicion venga de donde venga.
-- Operacional: el bloqueo es por fila (bodega, producto), no por tabla, asi que
-- solo se serializan movimientos del mismo producto en la misma bodega.
-- El SP no hace COMMIT; el bloqueo dura hasta que el llamador confirme.
--
CREATE OR REPLACE PROCEDURE SP_AJUSTAR_STOCK (
    p_id_producto  IN  NUMBER,
    p_id_bodega    IN  NUMBER,
    p_tipo         IN  VARCHAR2,
    p_cantidad     IN  NUMBER,
    p_observacion  IN  VARCHAR2 DEFAULT NULL,
    p_saldo_final  OUT NUMBER
) IS
    e_bloqueado    EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_bloqueado, -30006);   -- WAIT agotado

    v_tipo         VARCHAR2(10) := UPPER(TRIM(p_tipo));
    v_activa       BODEGA.activa%TYPE;
    v_aux          PLS_INTEGER;
    v_existe       BOOLEAN := TRUE;
    v_actual       EXISTENCIA.cantidad%TYPE;
    v_nuevo        EXISTENCIA.cantidad%TYPE;
    v_cant_mov     MOVIMIENTO_INVENTARIO.cantidad%TYPE;
    v_prefijo      VARCHAR2(80);
BEGIN
    -- Validacion de parametros
    IF v_tipo IS NULL OR v_tipo NOT IN ('ENTRADA', 'SALIDA', 'AJUSTE') THEN
        RAISE_APPLICATION_ERROR(-20111,
            'Tipo de movimiento invalido: ' || NVL(p_tipo, 'NULO') || '. Use ENTRADA, SALIDA o AJUSTE.');
    END IF;

    IF p_cantidad IS NULL OR p_cantidad < 0 OR p_cantidad <> TRUNC(p_cantidad)
       OR (v_tipo <> 'AJUSTE' AND p_cantidad = 0) THEN
        RAISE_APPLICATION_ERROR(-20112,
            'Cantidad invalida (' || NVL(TO_CHAR(p_cantidad), 'NULA') ||
            '). ENTRADA y SALIDA exigen entero positivo; AJUSTE, entero >= 0.');
    END IF;

    BEGIN
        SELECT 1 INTO v_aux FROM PRODUCTO WHERE id_producto = p_id_producto;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20113, 'El producto ' || p_id_producto || ' no existe.');
    END;

    BEGIN
        SELECT activa INTO v_activa FROM BODEGA WHERE id_bodega = p_id_bodega;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20114, 'La bodega ' || p_id_bodega || ' no existe.');
    END;
    IF v_activa <> 'S' THEN
        RAISE_APPLICATION_ERROR(-20114, 'La bodega ' || p_id_bodega || ' esta inactiva.');
    END IF;

    -- Lectura protegida de la existencia
    BEGIN
        SELECT cantidad INTO v_actual
          FROM EXISTENCIA
         WHERE id_bodega = p_id_bodega AND id_producto = p_id_producto
           FOR UPDATE WAIT 5;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            v_existe := FALSE;
            v_actual := 0;
    END;

    IF NOT v_existe THEN
        IF v_tipo = 'SALIDA' THEN
            RAISE_APPLICATION_ERROR(-20115,
                'SALIDA rechazada: el producto ' || p_id_producto ||
                ' no tiene existencia registrada en la bodega ' || p_id_bodega || '.');
        END IF;
        IF v_tipo = 'AJUSTE' AND p_cantidad = 0 THEN
            p_saldo_final := 0;                 -- nada que ajustar ni que crear
            RETURN;
        END IF;
        BEGIN
            INSERT INTO EXISTENCIA (id_bodega, id_producto, cantidad)
            VALUES (p_id_bodega, p_id_producto, 0);
        EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN           -- otra sesion la creo primero
                SELECT cantidad INTO v_actual
                  FROM EXISTENCIA
                 WHERE id_bodega = p_id_bodega AND id_producto = p_id_producto
                   FOR UPDATE WAIT 5;
        END;
    END IF;

    CASE v_tipo
        WHEN 'ENTRADA' THEN
            v_nuevo    := v_actual + p_cantidad;
            v_cant_mov := p_cantidad;
        WHEN 'SALIDA' THEN
            IF p_cantidad > v_actual THEN
                RAISE_APPLICATION_ERROR(-20030,
                    'Stock insuficiente: producto ' || p_id_producto || ', bodega ' || p_id_bodega ||
                    ', solicitado ' || p_cantidad || ', disponible ' || v_actual || '.');
            END IF;
            v_nuevo    := v_actual - p_cantidad;
            v_cant_mov := p_cantidad;
        WHEN 'AJUSTE' THEN
            v_nuevo    := p_cantidad;
            v_cant_mov := ABS(p_cantidad - v_actual);
            v_prefijo  := CASE WHEN p_cantidad >= v_actual THEN '(+) ' ELSE '(-) ' END ||
                          'Conteo ' || v_actual || ' -> ' || v_nuevo || '. ';
        ELSE
            RAISE_APPLICATION_ERROR(-20111, 'Tipo de movimiento invalido.');
    END CASE;

    IF v_cant_mov = 0 THEN                      -- AJUSTE sin diferencia
        p_saldo_final := v_actual;
        RETURN;
    END IF;

    UPDATE EXISTENCIA
       SET cantidad = v_nuevo
     WHERE id_bodega = p_id_bodega AND id_producto = p_id_producto;

    INSERT INTO MOVIMIENTO_INVENTARIO (id_movimiento, id_producto, id_bodega, tipo,
                                       cantidad, fecha_mov, id_pedido, observacion)
    VALUES (SEQ_MOVIMIENTO.NEXTVAL, p_id_producto, p_id_bodega, v_tipo,
            v_cant_mov, SYSDATE, NULL, SUBSTR(v_prefijo || p_observacion, 1, 200));

    p_saldo_final := v_nuevo;
EXCEPTION
    WHEN e_bloqueado THEN
        RAISE_APPLICATION_ERROR(-20117,
            'La existencia del producto ' || p_id_producto || ' en la bodega ' || p_id_bodega ||
            ' esta bloqueada por otra transaccion. Reintente.');
END SP_AJUSTAR_STOCK;
/

-- EVIDENCIA 1.2
-- RESULTADO ESPERADO:
--   ENTRADA 1011/B1 20 -> 29 | SALIDA 1011/B1 5 -> 24 | SALIDA 1011/B2 -> -20115
--   SALIDA 1005/B1 10 -> -20030 | ENTRADA 1011/B3 15 -> 15 (combinacion creada)
--   AJUSTE 1001/B1 118 -> 118 (movimiento de 2 con "(-)") | repetir -> 118 sin movimiento
--   Bodega 5 -> -20114 | tipo TRASLADO -> -20111 | cantidad -3 -> -20112
DECLARE
    v_mov_inicial NUMBER;
    PROCEDURE probar (p_desc VARCHAR2, p_prod NUMBER, p_bod NUMBER,
                      p_tipo VARCHAR2, p_cant NUMBER) IS
        v_saldo NUMBER;
    BEGIN
        SP_AJUSTAR_STOCK(p_prod, p_bod, p_tipo, p_cant, 'Evidencia 1.2', v_saldo);
        DBMS_OUTPUT.PUT_LINE(RPAD('OK        ' || p_desc, 48) || 'saldo final = ' || v_saldo);
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(RPAD('RECHAZADO ' || p_desc, 48) || SQLERRM);
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    SELECT NVL(MAX(id_movimiento), 0) INTO v_mov_inicial FROM MOVIMIENTO_INVENTARIO;

    probar('ENTRADA 1011 bodega 1, 20 und',      1011, 1, 'ENTRADA', 20);
    probar('SALIDA 1011 bodega 1, 5 und',        1011, 1, 'SALIDA',   5);
    probar('SALIDA 1011 bodega 2 (sin fila)',    1011, 2, 'SALIDA',   1);
    probar('SALIDA 1005 bodega 1, 10 und (hay 4)', 1005, 1, 'SALIDA', 10);
    probar('ENTRADA 1011 bodega 3 (crea fila)',  1011, 3, 'entrada', 15);
    probar('AJUSTE 1001 bodega 1, conteo 118',   1001, 1, 'AJUSTE', 118);
    probar('AJUSTE repetido, conteo 118',        1001, 1, 'AJUSTE', 118);
    probar('ENTRADA en bodega inactiva 5',       1001, 5, 'ENTRADA', 10);
    probar('Tipo invalido TRASLADO',             1001, 1, 'TRASLADO', 1);
    probar('Cantidad negativa',                  1001, 1, 'ENTRADA', -3);

    DBMS_OUTPUT.PUT_LINE('Movimientos generados por la prueba:');
    FOR m IN (SELECT id_movimiento, tipo, id_producto, id_bodega, cantidad, observacion
                FROM MOVIMIENTO_INVENTARIO
               WHERE id_movimiento > v_mov_inicial
               ORDER BY id_movimiento) LOOP
        DBMS_OUTPUT.PUT_LINE('  #' || m.id_movimiento || ' ' || RPAD(m.tipo, 8) ||
                             ' prod ' || m.id_producto || ' bod ' || m.id_bodega ||
                             ' cant ' || LPAD(m.cantidad, 4) || '  ' || m.observacion);
    END LOOP;
    ROLLBACK;
END;
/

------------------------------------------------------------------- 1.3 (3 pts)
-- SP_CREAR_PEDIDO
-- Crea la cabecera de un pedido en estado BORRADOR y devuelve el identificador
-- generado. Debe rechazar clientes inactivos y clientes sin cupo de credito
-- disponible, con mensajes distinguibles entre si.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) "Distinguibles" se resuelve con CODIGOS distintos (-20121 inexistente,
--    -20122 inactivo, -20123 sin cupo), no solo con textos: un programa cliente
--    decide por el codigo (p. ej. getErrorCode() en JDBC); el texto es para la
--    persona. Tres situaciones con un unico codigo obligarian a parsear texto.
-- 2) Orden de validacion: primero inactivo, luego cupo. Inactivo es una
--    condicion estructural (el cliente 506 tiene cupo libre de 3.000.000 y aun
--    asi no se le debe vender); informar "sin cupo" a un cliente inactivo daria
--    una causa equivocada.
-- 3) Cupo disponible = cupo - saldo se calcula sobre la misma fila ya leida en
--    lugar de invocar FN_CUPO_DISPONIBLE: la Parte 1 se compila antes que la 2
--    en este archivo, y la fila ya esta en memoria (una lectura en vez de dos).
--    En la Parte 6 si se reutiliza la funcion, porque alli es obligatorio.
-- 4) No se bloquea la fila del cliente: un BORRADOR no consume cupo, solo lo
--    exige mayor que cero. La validacion definitiva, con bloqueo, se hace al
--    facturar (Parte 6). Bloquear aqui serializaria sin beneficio a todos los
--    vendedores que abren pedidos del mismo cliente.
-- 5) SEQ_PEDIDO quedo sincronizada por el script 01 (siguiente valor = 8).
-- Operacional: el caso "cupo" es informativo, no una reserva: entre crear el
-- pedido y facturarlo el cupo puede agotarse; por eso Parte 6 valida de nuevo.
--
CREATE OR REPLACE PROCEDURE SP_CREAR_PEDIDO (
    p_id_cliente  IN  NUMBER,
    p_id_pedido   OUT NUMBER
) IS
    v_activo  CLIENTE.activo%TYPE;
    v_cupo    CLIENTE.cupo_credito%TYPE;
    v_saldo   CLIENTE.saldo_pendiente%TYPE;
    v_id      PEDIDO.id_pedido%TYPE;
BEGIN
    BEGIN
        SELECT activo, cupo_credito, saldo_pendiente
          INTO v_activo, v_cupo, v_saldo
          FROM CLIENTE
         WHERE id_cliente = p_id_cliente;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20121, 'El cliente ' || p_id_cliente || ' no existe.');
    END;

    IF v_activo <> 'S' THEN
        RAISE_APPLICATION_ERROR(-20122,
            'Cliente ' || p_id_cliente || ' INACTIVO: no se le pueden crear pedidos.');
    END IF;

    IF v_cupo - v_saldo <= 0 THEN
        RAISE_APPLICATION_ERROR(-20123,
            'Cliente ' || p_id_cliente || ' SIN CUPO disponible (cupo ' || v_cupo ||
            ', saldo pendiente ' || v_saldo || ').');
    END IF;

    v_id := SEQ_PEDIDO.NEXTVAL;
    INSERT INTO PEDIDO (id_pedido, id_cliente, fecha_pedido, estado, total)
    VALUES (v_id, p_id_cliente, SYSDATE, 'BORRADOR', 0);

    p_id_pedido := v_id;
END SP_CREAR_PEDIDO;
/

-- EVIDENCIA 1.3
-- RESULTADO ESPERADO: 503 crea pedido BORRADOR; 506 -> -20122; 505 -> -20123;
-- 502 crea (cupo 300.000 > 0); 999 -> -20121.
DECLARE
    PROCEDURE probar (p_desc VARCHAR2, p_cliente NUMBER) IS
        v_id     NUMBER;
        v_estado PEDIDO.estado%TYPE;
    BEGIN
        SP_CREAR_PEDIDO(p_cliente, v_id);
        SELECT estado INTO v_estado FROM PEDIDO WHERE id_pedido = v_id;
        DBMS_OUTPUT.PUT_LINE(RPAD('OK        ' || p_desc, 42) || 'pedido ' || v_id || ' en ' || v_estado);
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(RPAD('RECHAZADO ' || p_desc, 42) || 'SQLCODE ' || SQLCODE || ': ' || SQLERRM);
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    probar('Cliente 503 activo con cupo', 503);
    probar('Cliente 506 inactivo',        506);
    probar('Cliente 505 cupo agotado',    505);
    probar('Cliente 502 cupo parcial',    502);
    probar('Cliente 999 inexistente',     999);
    ROLLBACK;
END;
/


--==============================================================================
-- PARTE 2 — FUNCIONES                                         (8 puntos / 75 min)
--==============================================================================

------------------------------------------------------------------- 2.1 (2 pts)
-- FN_STOCK_DISPONIBLE
-- Retorna la cantidad disponible de un producto. Si se indica bodega, devuelve
-- el saldo de esa bodega; si p_id_bodega llega nulo, el consolidado de todas.
-- Un producto inexistente debe retornar cero y no una excepcion.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) Se usa SUM sin GROUP BY: una agregacion sin agrupamiento devuelve SIEMPRE
--    una fila (con NULL si no hay datos), por eso SELECT INTO nunca lanza
--    NO_DATA_FOUND y el producto inexistente retorna 0 via NVL. Se prefirio
--    esto a capturar NO_DATA_FOUND porque el "cero" sale de la semantica de la
--    consulta y no de un manejador que tambien podria ocultar otros errores.
-- 2) Dos consultas estaticas separadas por IF, en lugar de una sola con
--    "(p_id_bodega IS NULL OR id_bodega = p_id_bodega)": con la forma unica el
--    optimizador arma un solo plan para ambos casos y no puede usar el acceso
--    unico por PK_EXISTENCIA (bodega, producto) cuando si llega la bodega.
-- 3) "Disponible" excluye bodegas inactivas: stock en una bodega cerrada no se
--    puede despachar. Es la diferencia con V_STOCK_CONSOLIDADO, que suma todo.
-- 4) No se declara DETERMINISTIC: el resultado depende de datos que cambian;
--    marcarla asi permitiria a Oracle reutilizar resultados viejos.
-- Operacional: el consolidado recorre EXISTENCIA por producto sin un indice
-- que empiece por id_producto (la PK empieza por bodega); con millones de filas
-- convendria un indice (id_producto), que aqui no se crea por no modificar la
-- estructura.
--
CREATE OR REPLACE FUNCTION FN_STOCK_DISPONIBLE (
    p_id_producto IN NUMBER,
    p_id_bodega   IN NUMBER DEFAULT NULL
) RETURN NUMBER IS
    v_total NUMBER;
BEGIN
    IF p_id_bodega IS NULL THEN
        SELECT NVL(SUM(e.cantidad), 0)
          INTO v_total
          FROM EXISTENCIA e
          JOIN BODEGA b ON b.id_bodega = e.id_bodega
         WHERE e.id_producto = p_id_producto
           AND b.activa = 'S';
    ELSE
        SELECT NVL(SUM(e.cantidad), 0)
          INTO v_total
          FROM EXISTENCIA e
          JOIN BODEGA b ON b.id_bodega = e.id_bodega
         WHERE e.id_bodega   = p_id_bodega
           AND e.id_producto = p_id_producto
           AND b.activa = 'S';
    END IF;
    RETURN v_total;
END FN_STOCK_DISPONIBLE;
/

-- EVIDENCIA 2.1
-- RESULTADO ESPERADO: 120 | 160 | 0 | 0 | 0 | 470
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    DBMS_OUTPUT.PUT_LINE('1001 en bodega 1 ................ ' || FN_STOCK_DISPONIBLE(1001, 1));
    DBMS_OUTPUT.PUT_LINE('1001 consolidado ................ ' || FN_STOCK_DISPONIBLE(1001));
    DBMS_OUTPUT.PUT_LINE('1001 en bodega 3 (sin fila) ..... ' || FN_STOCK_DISPONIBLE(1001, 3));
    DBMS_OUTPUT.PUT_LINE('Producto 9999 inexistente ....... ' || FN_STOCK_DISPONIBLE(9999));
    DBMS_OUTPUT.PUT_LINE('1001 en bodega 5 (inactiva) ..... ' || FN_STOCK_DISPONIBLE(1001, 5));
    DBMS_OUTPUT.PUT_LINE('1007 consolidado ................ ' || FN_STOCK_DISPONIBLE(1007, NULL));
END;
/

------------------------------------------------------------------- 2.2 (2 pts)
-- FN_CUPO_DISPONIBLE
-- Retorna el cupo de credito disponible del cliente, entendido como cupo menos
-- saldo pendiente. Un cliente inactivo retorna cero y el resultado nunca puede
-- ser negativo.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) GREATEST(cupo - saldo, 0) garantiza el "nunca negativo" en la propia
--    formula. Hoy ningun cliente tiene saldo > cupo, pero nada en el esquema lo
--    impide (no hay CHECK saldo <= cupo): basta bajar el cupo de un cliente con
--    deuda para que la resta sea negativa.
-- 2) Cliente inexistente retorna 0 (a quien no existe no se le puede vender)
--    en lugar de una excepcion, porque la funcion se usa desde SQL (2.4) y en
--    validaciones de la Parte 6: un error en una fila abortaria toda la
--    consulta. Costo de la decision: un id mal digitado no se distingue de un
--    cliente sin cupo; quien necesite distinguirlo debe validar existencia
--    antes (lo hace SP_CREAR_PEDIDO).
-- 3) Se usan %TYPE para que un cambio de precision en CLIENTE no rompa la
--    funcion.
-- Operacional: lectura por PK, costo constante. Su resultado es una foto: dos
-- sesiones pueden ver el mismo cupo libre; por eso la Parte 6 bloquea la fila
-- del cliente antes de usarla para decidir.
--
CREATE OR REPLACE FUNCTION FN_CUPO_DISPONIBLE (
    p_id_cliente IN NUMBER
) RETURN NUMBER IS
    v_cupo    CLIENTE.cupo_credito%TYPE;
    v_saldo   CLIENTE.saldo_pendiente%TYPE;
    v_activo  CLIENTE.activo%TYPE;
BEGIN
    SELECT cupo_credito, saldo_pendiente, activo
      INTO v_cupo, v_saldo, v_activo
      FROM CLIENTE
     WHERE id_cliente = p_id_cliente;

    IF v_activo <> 'S' THEN
        RETURN 0;
    END IF;
    RETURN GREATEST(v_cupo - v_saldo, 0);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0;
END FN_CUPO_DISPONIBLE;
/

-- EVIDENCIA 2.2
-- RESULTADO ESPERADO: 501 6750000 | 502 300000 | 503 2000000 | 504 8600000
-- 505 0 (agotado) | 506 0 (inactivo) | 507 5200000 | 999 0 (inexistente)
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    FOR c IN (SELECT id_cliente, activo, cupo_credito, saldo_pendiente FROM CLIENTE
              UNION ALL
              SELECT 999, NULL, NULL, NULL FROM DUAL
              ORDER BY 1) LOOP
        DBMS_OUTPUT.PUT_LINE('Cliente ' || c.id_cliente ||
                             ' activo=' || NVL(c.activo, '-') ||
                             ' cupo=' || NVL(TO_CHAR(c.cupo_credito), '-') ||
                             ' saldo=' || NVL(TO_CHAR(c.saldo_pendiente), '-') ||
                             ' -> disponible ' || FN_CUPO_DISPONIBLE(c.id_cliente));
    END LOOP;
END;
/

------------------------------------------------------------------- 2.3 (3 pts)
-- FN_CALCULAR_DESCUENTO
-- Retorna el VALOR en pesos del descuento aplicable, segun estas reglas
-- acumulables:
--     Monto mayor o igual a 2.000.000 ................. 8%
--     Monto entre 800.000 y 1.999.999 ................. 5%
--     Monto menor a 800.000 ........................... 0%
--     Adicional si el cliente no tiene saldo pendiente . 2%
--     Tope maximo acumulado ........................... 10%
-- La funcion retorna el valor del descuento, no el porcentaje.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) Rangos con ">= 2000000" y ">= 800000" en IF/ELSIF, no con BETWEEN 800000
--    AND 1999999: con BETWEEN un monto como 1.999.999,50 (los montos tienen dos
--    decimales) no cae en ningun rango. Con limites inferiores encadenados cada
--    monto cae en exactamente un tramo.
-- 2) "Acumulables" se interpreta como que el 2% se suma a cualquier tramo,
--    incluido el 0%: un cliente sin deuda que compra 500.000 recibe 2%.
-- 3) El tope se aplica con LEAST sobre el porcentaje acumulado y no sobre el
--    valor. Con las reglas actuales el maximo es 8 + 2 = 10, asi que el tope no
--    recorta nada hoy; se deja explicito como constante para que un cambio de
--    porcentajes no rompa la regla silenciosamente.
-- 4) Se redondea a 2 decimales (la precision de las columnas de dinero) para
--    que total = subtotal - descuento cuadre exactamente al guardarse.
-- 5) Cliente inexistente: sin adicional (no se puede afirmar que no debe).
--    Monto nulo o <= 0: descuento 0, no error.
-- 6) El saldo se lee al momento de la llamada: en la Parte 6 la funcion se
--    invoca ANTES de sumar la factura al saldo; invertir ese orden quitaria el
--    2% a todo cliente que factura por primera vez.
--
CREATE OR REPLACE FUNCTION FN_CALCULAR_DESCUENTO (
    p_id_cliente IN NUMBER,
    p_monto      IN NUMBER
) RETURN NUMBER IS
    c_tope_pct  CONSTANT NUMBER := 10;
    v_pct       NUMBER := 0;
    v_saldo     CLIENTE.saldo_pendiente%TYPE;
BEGIN
    IF p_monto IS NULL OR p_monto <= 0 THEN
        RETURN 0;
    END IF;

    IF p_monto >= 2000000 THEN
        v_pct := 8;
    ELSIF p_monto >= 800000 THEN
        v_pct := 5;
    ELSE
        v_pct := 0;
    END IF;

    BEGIN
        SELECT saldo_pendiente INTO v_saldo FROM CLIENTE WHERE id_cliente = p_id_cliente;
        IF v_saldo = 0 THEN
            v_pct := v_pct + 2;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
    END;

    v_pct := LEAST(v_pct, c_tope_pct);
    RETURN ROUND(p_monto * v_pct / 100, 2);
END FN_CALCULAR_DESCUENTO;
/

-- EVIDENCIA 2.3
-- RESULTADO ESPERADO (503 sin saldo, 501 con saldo):
--   503 2.500.000 -> 250000 (10%) | 501 2.500.000 -> 200000 (8%)
--   503 1.000.000 -> 70000 (7%)   | 501 800.000 -> 40000 (5%)
--   501 799.999,99 -> 0           | 503 500.000 -> 10000 (2%)
--   501 1.999.999,50 -> 99999.98 (5%) | 503 0 -> 0
DECLARE
    PROCEDURE probar (p_cliente NUMBER, p_monto NUMBER) IS
        v_desc NUMBER := FN_CALCULAR_DESCUENTO(p_cliente, p_monto);
    BEGIN
        DBMS_OUTPUT.PUT_LINE('Cliente ' || p_cliente || '  monto ' || LPAD(TO_CHAR(p_monto, 'FM999,999,990.00'), 14) ||
                             '  descuento ' || LPAD(TO_CHAR(v_desc, 'FM999,999,990.00'), 12) ||
                             '  (' || CASE WHEN p_monto > 0 THEN ROUND(v_desc / p_monto * 100, 2) ELSE 0 END || '%)');
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    probar(503, 2500000);
    probar(501, 2500000);
    probar(503, 1000000);
    probar(501,  800000);
    probar(501,  799999.99);
    probar(503,  500000);
    probar(501, 1999999.50);
    probar(503,       0);
END;
/

------------------------------------------------------------------- 2.4 (1 pt)
-- Escriba una consulta que liste los clientes activos con su cupo disponible,
-- usando la funcion del punto 2.2, ordenados de mayor a menor.
-- Explique por que una funcion definida por el usuario puede invocarse desde
-- una sentencia SQL y que restriccion debe cumplir para poder hacerlo.
-------------------------------------------------------------------------------
-- RESPUESTA:
-- POR QUE PUEDE INVOCARSE: una funcion almacenada es un objeto del esquema
-- registrado en el diccionario, igual que una tabla. Cuando el motor SQL
-- encuentra su nombre en una expresion, la resuelve como cualquier funcion y
-- hace un cambio de contexto al motor PL/SQL para ejecutarla por cada fila.
-- Una funcion declarada dentro de un bloque anonimo no puede usarse asi porque
-- no existe en el diccionario.
--
-- RESTRICCIONES que debe cumplir:
--   * Solo parametros IN y tipos de dato SQL en parametros y retorno (NUMBER,
--     VARCHAR2, DATE...). Un parametro OUT o un retorno BOOLEAN (en 19c) la
--     hacen invocable solo desde PL/SQL.
--   * Invocada desde un SELECT no puede modificar la base de datos (INSERT,
--     UPDATE, DELETE -> ORA-14551) ni hacer COMMIT/ROLLBACK: una consulta no
--     puede tener efectos laterales sobre la transaccion.
--   * Invocada desde un INSERT/UPDATE/DELETE no puede leer ni modificar la
--     tabla que esa sentencia esta modificando (ORA-04091, tabla mutante).
-- FN_CUPO_DISPONIBLE cumple todo: un parametro IN NUMBER, retorna NUMBER y
-- solo hace SELECT.
--
-- ANALISIS OPERACIONAL: la funcion ejecuta su propio SELECT por cada fila de
-- la consulta externa (N+1 consultas y N cambios de contexto). Con 6 clientes
-- es irrelevante; con cientos de miles de filas la expresion inline
-- GREATEST(cupo_credito - saldo_pendiente, 0) seria mucho mas barata. Ademas,
-- cada SELECT interno toma su propia foto de lectura, no la de la consulta
-- externa: si otra sesion confirma cambios durante la consulta, las filas
-- pueden reflejar momentos distintos.
--
SELECT c.id_cliente,
       c.nombre,
       c.cupo_credito,
       c.saldo_pendiente,
       FN_CUPO_DISPONIBLE(c.id_cliente) AS cupo_disponible
  FROM CLIENTE c
 WHERE c.activo = 'S'
 ORDER BY cupo_disponible DESC, c.id_cliente;
-- RESULTADO ESPERADO: 504 (8.600.000), 501, 507, 503, 502, 505 (0). El 506 no
-- aparece por inactivo.


--==============================================================================
-- PARTE 3 — CURSORES                                         (10 puntos / 90 min)
--==============================================================================

------------------------------------------------------------------- 3.1 (2 pts)
-- Bloque anonimo que recorra, con un CURSOR EXPLICITO, los productos cuyo stock
-- consolidado este por debajo del stock minimo, e imprima un reporte con codigo,
-- nombre, stock actual, stock minimo y unidades faltantes, mas el total de
-- productos en esa condicion.
-- Debe usar OPEN, FETCH y CLOSE de forma explicita. El ciclo FOR implicito no se
-- acepta en este punto.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) Se consulta V_STOCK_CONSOLIDADO porque ya encapsula la suma por producto;
--    rehacer el GROUP BY en el cursor duplicaria la definicion de "consolidado".
-- 2) Se une con PRODUCTO para excluir inactivos: el 1015 tiene stock 0 contra
--    minimo 20, pero esta descontinuado; incluirlo generaria una alerta de
--    reposicion para algo que no se vuelve a comprar.
-- 3) El filtro va en el WHERE del cursor y no en un IF dentro del ciclo: asi
--    solo viajan al PL/SQL las filas del reporte, en vez de traer todos los
--    productos para descartar la mayoria.
-- 4) El total sale de %ROWCOUNT (filas extraidas hasta el momento), leido
--    ANTES del CLOSE, porque despues de cerrar el atributo ya no es valido.
--    Evita un contador manual que puede desincronizarse.
-- 5) EXIT WHEN %NOTFOUND va inmediatamente despues del FETCH: si va despues
--    del PUT_LINE, la ultima fila se imprime dos veces (el FETCH fallido deja
--    el registro con los valores anteriores).
-- 6) El manejador cierra el cursor si quedo abierto y relanza: sin eso, un
--    error a mitad del ciclo deja el cursor abierto en la sesion; repetido en
--    un proceso largo termina en ORA-01000 (maximo de cursores abiertos).
--
DECLARE
    CURSOR c_bajo_minimo IS
        SELECT v.codigo,
               v.producto,
               v.stock_total,
               v.stock_minimo,
               v.stock_minimo - v.stock_total AS faltante
          FROM V_STOCK_CONSOLIDADO v
          JOIN PRODUCTO p ON p.id_producto = v.id_producto
         WHERE p.activo = 'S'
           AND v.stock_total < v.stock_minimo
         ORDER BY faltante DESC, v.codigo;

    r_prod   c_bajo_minimo%ROWTYPE;
    v_total  PLS_INTEGER := 0;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    DBMS_OUTPUT.PUT_LINE(RPAD('CODIGO', 10) || RPAD('PRODUCTO', 32) ||
                         LPAD('ACTUAL', 8) || LPAD('MINIMO', 8) || LPAD('FALTAN', 8));
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 66, '-'));

    OPEN c_bajo_minimo;
    LOOP
        FETCH c_bajo_minimo INTO r_prod;
        EXIT WHEN c_bajo_minimo%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(RPAD(r_prod.codigo, 10) || RPAD(r_prod.producto, 32) ||
                             LPAD(r_prod.stock_total, 8) || LPAD(r_prod.stock_minimo, 8) ||
                             LPAD(r_prod.faltante, 8));
    END LOOP;
    v_total := c_bajo_minimo%ROWCOUNT;
    CLOSE c_bajo_minimo;

    DBMS_OUTPUT.PUT_LINE(RPAD('-', 66, '-'));
    DBMS_OUTPUT.PUT_LINE('Total de productos bajo el stock minimo: ' || v_total);
EXCEPTION
    WHEN OTHERS THEN
        IF c_bajo_minimo%ISOPEN THEN
            CLOSE c_bajo_minimo;
        END IF;
        RAISE;
END;
/
-- RESULTADO ESPERADO: ME-0001 (470 de 500, faltan 30) y FG-0002 (9 de 25,
-- faltan 16). Total: 2.

------------------------------------------------------------------- 3.2 (2 pts)
-- Bloque anonimo con un CURSOR PARAMETRIZADO que reciba identificador de cliente
-- y un rango de fechas, y muestre los pedidos CONFIRMADOS de ese cliente en ese
-- rango, con su total y la cantidad de lineas de cada pedido.
-- Pruebelo con el cliente 501 entre 2026-01-01 y 2026-12-31.
-- Los parametros deben declararse en el cursor, no tomarse del alcance del bloque.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) Parametros formales en el cursor (pc_*) y no variables del bloque: el
--    cursor queda autocontenido y reutilizable con distintos valores en el
--    mismo bloque (se abre tres veces abajo). Si leyera variables del bloque,
--    su resultado dependeria de su valor en el momento del OPEN, un
--    acoplamiento oculto que produce errores dificiles de ver.
-- 2) Rango con "fecha >= desde AND fecha < hasta + 1" y no BETWEEN: DATE
--    guarda hora. Un pedido del 31-dic a las 15:00 es mayor que 31-dic 00:00 y
--    BETWEEN lo excluiria. Ademas no se aplica TRUNC sobre la columna, lo que
--    permitiria usar un indice sobre fecha_pedido si existiera.
-- 3) LEFT JOIN + COUNT(d.linea): un pedido confirmado sin lineas aparece con 0
--    en lugar de desaparecer (con INNER JOIN se perderia), y COUNT(columna) no
--    cuenta la fila nula que genera el LEFT JOIN, cosa que COUNT(*) si haria.
-- 4) Aqui si se usa el FOR de cursor: el enunciado lo prohibe solo en 3.1, y el
--    FOR abre, recorre y cierra aun ante excepciones.
--
DECLARE
    CURSOR c_pedidos (pc_cliente PEDIDO.id_cliente%TYPE,
                      pc_desde   DATE,
                      pc_hasta   DATE) IS
        SELECT p.id_pedido,
               p.fecha_pedido,
               p.total,
               COUNT(d.linea) AS lineas
          FROM PEDIDO p
          LEFT JOIN DETALLE_PEDIDO d ON d.id_pedido = p.id_pedido
         WHERE p.id_cliente   = pc_cliente
           AND p.estado       = 'CONFIRMADO'
           AND p.fecha_pedido >= TRUNC(pc_desde)
           AND p.fecha_pedido <  TRUNC(pc_hasta) + 1
         GROUP BY p.id_pedido, p.fecha_pedido, p.total
         ORDER BY p.fecha_pedido;

    PROCEDURE reporte (p_cliente NUMBER, p_desde DATE, p_hasta DATE) IS
        v_n     PLS_INTEGER := 0;
        v_suma  NUMBER := 0;
    BEGIN
        DBMS_OUTPUT.PUT_LINE('Cliente ' || p_cliente || ' entre ' || TO_CHAR(p_desde, 'YYYY-MM-DD') ||
                             ' y ' || TO_CHAR(p_hasta, 'YYYY-MM-DD'));
        FOR r IN c_pedidos(p_cliente, p_desde, p_hasta) LOOP
            v_n    := v_n + 1;
            v_suma := v_suma + r.total;
            DBMS_OUTPUT.PUT_LINE('   Pedido ' || LPAD(r.id_pedido, 4) || '  ' ||
                                 TO_CHAR(r.fecha_pedido, 'YYYY-MM-DD') ||
                                 '  total ' || LPAD(TO_CHAR(r.total, 'FM999,999,990'), 12) ||
                                 '  lineas ' || r.lineas);
        END LOOP;
        DBMS_OUTPUT.PUT_LINE('   => ' || v_n || ' pedido(s) confirmado(s), suma ' ||
                             TO_CHAR(v_suma, 'FM999,999,990'));
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    reporte(501, DATE '2026-01-01', DATE '2026-12-31');
    reporte(501, DATE '2026-07-01', DATE '2026-07-31');
    reporte(507, DATE '2026-01-01', DATE '2026-12-31');
END;
/
-- RESULTADO ESPERADO: 501 en 2026 -> pedidos 1 (1.286.500, 3 lineas) y 2
-- (641.000, 2 lineas); el 6 no sale por estar en BORRADOR. 501 en julio ->
-- solo el 2. 507 -> ninguno (su unico pedido esta ANULADO).

------------------------------------------------------------------- 3.3 (3 pts)
-- Bloque anonimo con un CURSOR FOR UPDATE que recorra los productos de una
-- categoria y ajuste su precio un porcentaje dado, usando WHERE CURRENT OF.
--   * No debe modificar productos inactivos
--   * El precio resultante no puede quedar por debajo del costo mas el margen
--     minimo de la categoria
-- Explique que bloqueo genera FOR UPDATE, cuanto dura, y por que WHERE CURRENT OF
-- es preferible a un UPDATE por clave primaria.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- QUE BLOQUEO GENERA: un bloqueo exclusivo de FILA (TX) sobre cada fila que
-- cumple el WHERE del cursor, mas un bloqueo de TABLA (TM) que impide DDL
-- sobre PRODUCTO (ALTER, DROP) mientras la transaccion este abierta. Otras
-- sesiones pueden LEER esas filas (lectura consistente, sin bloqueo), pero un
-- UPDATE, DELETE o SELECT FOR UPDATE sobre ellas queda en espera.
-- "FOR UPDATE OF p.precio_unitario" limita el bloqueo a la tabla de esa
-- columna: sin el OF, el JOIN tambien bloquearia la fila de CATEGORIA y
-- frenaria a cualquiera que modifique esa categoria sin necesidad.
-- CUANTO DURA: se adquiere completo en el OPEN (Oracle bloquea todas las filas
-- del resultado antes del primer FETCH, no a medida que se recorren) y se
-- libera en el COMMIT o ROLLBACK, NO en el CLOSE. Por eso un COMMIT dentro del
-- ciclo libera los bloqueos y el siguiente FETCH falla (ORA-01002).
-- WAIT 5: si otra sesion tiene bloqueado algun producto de la categoria, el
-- bloque falla a los 5 s (ORA-30006) en lugar de esperar indefinidamente.
--
-- POR QUE WHERE CURRENT OF: actualiza la fila por el ROWID de la ultima fila
-- extraida, que es exactamente la fila leida y bloqueada. Un UPDATE por PK
-- vuelve a buscar la fila por el indice (acceso adicional) y desacopla la
-- escritura del bloqueo: nada obliga a que el WHERE del UPDATE coincida con el
-- del cursor, y un error ahi modificaria filas no bloqueadas o no validadas.
-- Con indice por PK la diferencia de rendimiento es pequena; el argumento
-- principal es la correspondencia garantizada lectura-bloqueo-escritura.
--
-- DECISIONES DE NEGOCIO:
-- * Los inactivos se excluyen en el WHERE del cursor, no con un IF: asi ni
--   siquiera se bloquean filas que no se van a modificar.
-- * Si el nuevo precio queda bajo el piso costo*(1+margen/100), se fija en el
--   piso en lugar de omitir el producto: una rebaja debe aplicarse hasta donde
--   el margen lo permita. El piso se redondea HACIA ARRIBA al centavo (CEIL):
--   ROUND podria dejarlo una fraccion por debajo del minimo y el trigger 5.3 lo
--   rechazaria.
-- * Evidencia: categoria 2 con -10%, que muestra ambos casos. Se hace ROLLBACK
--   para no alterar los datos; en operacion real ahi va COMMIT.
--
DECLARE
    c_id_categoria  CONSTANT CATEGORIA.id_categoria%TYPE := 2;
    c_porcentaje    CONSTANT NUMBER := -10;

    CURSOR c_precios (pc_categoria CATEGORIA.id_categoria%TYPE) IS
        SELECT p.id_producto, p.codigo, p.nombre,
               p.precio_unitario, p.costo_unitario, c.margen_minimo
          FROM PRODUCTO p
          JOIN CATEGORIA c ON c.id_categoria = p.id_categoria
         WHERE p.id_categoria = pc_categoria
           AND p.activo = 'S'
           FOR UPDATE OF p.precio_unitario WAIT 5;

    v_nuevo      PRODUCTO.precio_unitario%TYPE;
    v_piso       PRODUCTO.precio_unitario%TYPE;
    v_n          PLS_INTEGER := 0;
    v_en_piso    PLS_INTEGER := 0;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    FOR r IN c_precios(c_id_categoria) LOOP
        v_piso  := CEIL(r.costo_unitario * (1 + r.margen_minimo / 100) * 100) / 100;
        v_nuevo := ROUND(r.precio_unitario * (1 + c_porcentaje / 100), 2);

        IF v_nuevo < v_piso THEN
            v_nuevo   := v_piso;
            v_en_piso := v_en_piso + 1;
        END IF;

        UPDATE PRODUCTO
           SET precio_unitario = v_nuevo
         WHERE CURRENT OF c_precios;

        v_n := v_n + 1;
        DBMS_OUTPUT.PUT_LINE(RPAD(r.codigo, 9) || RPAD(r.nombre, 32) ||
                             ' ' || LPAD(r.precio_unitario, 9) || ' -> ' || LPAD(v_nuevo, 9) ||
                             '  (piso ' || v_piso || ')' ||
                             CASE WHEN v_nuevo = v_piso THEN '  AJUSTADO AL PISO' END);
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('Productos actualizados: ' || v_n || ', de ellos fijados en el piso: ' || v_en_piso);
    ROLLBACK;   -- evidencia: se revierte. En operacion real: COMMIT
    DBMS_OUTPUT.PUT_LINE('ROLLBACK ejecutado: cambios revertidos y bloqueos liberados.');
END;
/
-- RESULTADO ESPERADO: HE-0001 320000 -> 289100 (piso); HE-0002 285000 ->
-- 256500; HE-0003 480000 -> 438960 (piso). 3 actualizados, 2 en el piso.

------------------------------------------------------------------- 3.4 (2 pts)
-- SP_LISTAR_MOVIMIENTOS
-- Procedimiento que reciba un identificador de producto y devuelva un
-- SYS_REFCURSOR con los movimientos de inventario de ese producto, ordenados
-- por fecha. Incluya un bloque anonimo que consuma el cursor devuelto y lo cierre.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) SYS_REFCURSOR en lugar de devolver una coleccion: el procedimiento solo
--    ABRE la consulta y entrega un puntero; las filas se leen cuando el
--    consumidor hace FETCH. No se materializa el resultado completo en memoria
--    del servidor, y el mismo procedimiento sirve a PL/SQL, Java o Python, que
--    reciben el cursor como un ResultSet.
-- 2) Responsabilidad del cierre: el SP no puede cerrar lo que entrega, asi que
--    el consumidor lo cierra, tambien en el manejador de errores. Un cursor de
--    referencia olvidado sigue ocupando un cursor abierto de la sesion; en un
--    pool de conexiones que reutiliza sesiones, se acumulan hasta ORA-01000.
-- 3) ORDER BY fecha_mov, id_movimiento: varios movimientos comparten fecha
--    (p. ej. las tres salidas del pedido 1 el 2026-06-10). Sin el segundo
--    criterio el orden entre ellos no esta garantizado y puede cambiar entre
--    ejecuciones.
-- 4) Producto inexistente devuelve un cursor vacio, no un error: "no tiene
--    movimientos" es una respuesta valida y el consumidor no necesita un caso
--    especial.
-- 5) Se incluye el nombre de la bodega (JOIN) para que el consumidor no tenga
--    que hacer una consulta adicional por cada fila.
--
CREATE OR REPLACE PROCEDURE SP_LISTAR_MOVIMIENTOS (
    p_id_producto IN  NUMBER,
    p_cursor      OUT SYS_REFCURSOR
) IS
BEGIN
    OPEN p_cursor FOR
        SELECT m.id_movimiento,
               m.fecha_mov,
               m.tipo,
               m.cantidad,
               m.id_bodega,
               b.nombre AS bodega,
               m.id_pedido,
               m.observacion
          FROM MOVIMIENTO_INVENTARIO m
          JOIN BODEGA b ON b.id_bodega = m.id_bodega
         WHERE m.id_producto = p_id_producto
         ORDER BY m.fecha_mov, m.id_movimiento;
END SP_LISTAR_MOVIMIENTOS;
/

-- Bloque consumidor:
-- RESULTADO ESPERADO para 1001: movimientos 1 (ENTRADA 150), 6 (SALIDA 5,
-- pedido 1), 8 (ENTRADA 40 bodega norte), 20 (AJUSTE 25). Total 4.
DECLARE
    v_cursor      SYS_REFCURSOR;
    v_id          MOVIMIENTO_INVENTARIO.id_movimiento%TYPE;
    v_fecha       MOVIMIENTO_INVENTARIO.fecha_mov%TYPE;
    v_tipo        MOVIMIENTO_INVENTARIO.tipo%TYPE;
    v_cantidad    MOVIMIENTO_INVENTARIO.cantidad%TYPE;
    v_id_bodega   MOVIMIENTO_INVENTARIO.id_bodega%TYPE;
    v_bodega      BODEGA.nombre%TYPE;
    v_pedido      MOVIMIENTO_INVENTARIO.id_pedido%TYPE;
    v_obs         MOVIMIENTO_INVENTARIO.observacion%TYPE;
    c_producto    CONSTANT NUMBER := 1001;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    SP_LISTAR_MOVIMIENTOS(c_producto, v_cursor);
    LOOP
        FETCH v_cursor INTO v_id, v_fecha, v_tipo, v_cantidad, v_id_bodega, v_bodega, v_pedido, v_obs;
        EXIT WHEN v_cursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('#' || LPAD(v_id, 3) || '  ' || TO_CHAR(v_fecha, 'YYYY-MM-DD') || '  ' ||
                             RPAD(v_tipo, 8) || LPAD(v_cantidad, 5) || '  ' || RPAD(v_bodega, 16) ||
                             ' pedido ' || NVL(TO_CHAR(v_pedido), '-') || '  ' || v_obs);
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('Movimientos listados: ' || v_cursor%ROWCOUNT);
    CLOSE v_cursor;
    DBMS_OUTPUT.PUT_LINE('Cursor cerrado. ISOPEN = ' ||
                         CASE WHEN v_cursor%ISOPEN THEN 'TRUE' ELSE 'FALSE' END);
EXCEPTION
    WHEN OTHERS THEN
        IF v_cursor%ISOPEN THEN
            CLOSE v_cursor;
        END IF;
        RAISE;
END;
/

------------------------------------------------------------------- 3.5 (1 pt)
-- Bloque anonimo que cargue con BULK COLLECT los productos de una categoria en
-- una coleccion y use FORALL para actualizar su stock minimo.
-- Explique que costo concreto elimina esta tecnica y a partir de que volumen
-- empieza a notarse.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- COSTO QUE ELIMINA: el CAMBIO DE CONTEXTO entre el motor PL/SQL y el motor
-- SQL. En un ciclo fila a fila, cada FETCH y cada UPDATE es un viaje de ida y
-- vuelta entre ambos motores (N filas = 2N cambios). BULK COLLECT trae todas
-- las filas en un solo cambio y FORALL envia el UPDATE con toda la coleccion
-- en otro: 2 cambios en total, sin importar N.
-- CUANDO SE NOTA: con las 3 filas de la categoria 3 la ganancia no es medible;
-- el beneficio aparece en el orden de miles de filas y crece linealmente. Con
-- volumen grande hay un costo nuevo: la coleccion vive en la memoria de la
-- sesion (PGA), por lo que en tablas grandes se usa BULK COLLECT ... LIMIT
-- (lotes de 100 a 1000) dentro de un ciclo, para acotar la memoria.
-- ANALISIS: si la regla se puede expresar en SQL, como aqui, un solo
-- "UPDATE ... SET stock_minimo = CEIL(stock_minimo * 1.10)" es aun mejor (cero
-- cambios de contexto por fila). BULK COLLECT/FORALL se justifica cuando entre
-- la lectura y la escritura hay logica que solo puede ejecutarse en PL/SQL;
-- aqui el calculo se hace en un ciclo PL/SQL para representar ese caso.
-- SQL%BULK_ROWCOUNT(i) confirma cuantas filas afecto cada elemento: un 0
-- revelaria un producto borrado entre la carga y la actualizacion.
--
DECLARE
    TYPE t_ids     IS TABLE OF PRODUCTO.id_producto%TYPE;
    TYPE t_codigos IS TABLE OF PRODUCTO.codigo%TYPE;
    TYPE t_minimos IS TABLE OF PRODUCTO.stock_minimo%TYPE;

    c_id_categoria CONSTANT CATEGORIA.id_categoria%TYPE := 3;
    c_factor       CONSTANT NUMBER := 1.10;

    v_ids      t_ids;
    v_codigos  t_codigos;
    v_minimos  t_minimos;
    v_nuevos   t_minimos := t_minimos();
    v_total    PLS_INTEGER;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');

    SELECT id_producto, codigo, stock_minimo
      BULK COLLECT INTO v_ids, v_codigos, v_minimos
      FROM PRODUCTO
     WHERE id_categoria = c_id_categoria
       AND activo = 'S'
     ORDER BY id_producto;

    IF v_ids.COUNT = 0 THEN
        DBMS_OUTPUT.PUT_LINE('La categoria no tiene productos activos.');
        RETURN;
    END IF;

    v_nuevos.EXTEND(v_ids.COUNT);
    FOR i IN 1 .. v_ids.COUNT LOOP
        v_nuevos(i) := CEIL(v_minimos(i) * c_factor);
    END LOOP;

    FORALL i IN 1 .. v_ids.COUNT
        UPDATE PRODUCTO
           SET stock_minimo = v_nuevos(i)
         WHERE id_producto  = v_ids(i);

    v_total := SQL%ROWCOUNT;
    FOR i IN 1 .. v_ids.COUNT LOOP
        DBMS_OUTPUT.PUT_LINE(RPAD(v_codigos(i), 9) || 'stock minimo ' || LPAD(v_minimos(i), 4) ||
                             ' -> ' || LPAD(v_nuevos(i), 4) ||
                             '   filas afectadas: ' || SQL%BULK_ROWCOUNT(i));
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('Filas cargadas: ' || v_ids.COUNT || ' | filas actualizadas: ' || v_total);
    ROLLBACK;   -- evidencia: se revierte
END;
/
-- RESULTADO ESPERADO: ME-0001 500 -> 550, ME-0002 40 -> 44, ME-0003 60 -> 66.


--==============================================================================
-- PARTE 4 — MANEJO DE EXCEPCIONES                             (9 puntos / 75 min)
--==============================================================================

------------------------------------------------------------------- 4.1 (2 pts)
-- FN_PRECIO_PRODUCTO
-- Funcion que reciba el CODIGO de un producto y retorne su precio, manejando
-- explicitamente NO_DATA_FOUND y TOO_MANY_ROWS, con retorno de -1 y -2
-- respectivamente, e imprimiendo un mensaje descriptivo en cada caso.
-- Explique en que situacion real se produciria TOO_MANY_ROWS sobre esta tabla,
-- considerando las restricciones que hoy tiene.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) -1 y -2 son valores centinela seguros porque CK_PRODUCTO_PRECIO obliga a
--    precio > 0: ningun precio real puede confundirse con un codigo de error.
-- 2) La busqueda es tolerante: UPPER(TRIM(codigo)) = UPPER(TRIM(p_codigo)),
--    porque quien consulta escribe 'hm-0001' o ' HM-0001 ' y espera encontrar
--    el producto.
-- SITUACION REAL DE TOO_MANY_ROWS: con una igualdad exacta sobre codigo es
-- imposible, porque UK_PRODUCTO_CODIGO no admite dos codigos iguales. Pero esa
-- restriccion distingue mayusculas: 'HM-0001' y 'hm-0001' son valores
-- DISTINTOS para la UK y ambos pueden existir, por ejemplo si una migracion o
-- una carga masiva inserta directo en la tabla sin pasar por
-- SP_REGISTRAR_PRODUCTO (que normaliza a mayusculas). Para el negocio es el
-- mismo codigo; para la busqueda normalizada son dos filas -> TOO_MANY_ROWS.
-- La evidencia lo reproduce con un INSERT directo. La restriccion protege el
-- valor almacenado, no la regla de negocio; la solucion de fondo seria una UK
-- sobre UPPER(codigo) (indice unico basado en funcion), que no se crea por no
-- modificar la estructura.
-- 3) Costo de la decision: UPPER(TRIM(codigo)) impide usar el indice de la UK
--    (recorrido completo). Con 15 productos es irrelevante; con catalogos
--    grandes se resuelve con el mismo indice basado en funcion.
-- 4) Se capturan SOLO las dos excepciones pedidas: cualquier otro error se
--    propaga, porque retornar un centinela para errores no previstos los
--    haria invisibles.
--
CREATE OR REPLACE FUNCTION FN_PRECIO_PRODUCTO (
    p_codigo IN VARCHAR2
) RETURN NUMBER IS
    v_precio PRODUCTO.precio_unitario%TYPE;
BEGIN
    SELECT precio_unitario
      INTO v_precio
      FROM PRODUCTO
     WHERE UPPER(TRIM(codigo)) = UPPER(TRIM(p_codigo));
    RETURN v_precio;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('FN_PRECIO_PRODUCTO: no existe ningun producto con codigo "' ||
                             p_codigo || '". Retorna -1.');
        RETURN -1;
    WHEN TOO_MANY_ROWS THEN
        DBMS_OUTPUT.PUT_LINE('FN_PRECIO_PRODUCTO: el codigo "' || p_codigo ||
                             '" coincide con mas de un producto (codigos que solo difieren en ' ||
                             'mayusculas/espacios). Retorna -2.');
        RETURN -2;
END FN_PRECIO_PRODUCTO;
/

-- EVIDENCIA 4.1
-- RESULTADO ESPERADO: HM-0001 45000 | ' hm-0002 ' 62000 | ZZ-9999 -1 |
-- tras insertar 'hm-0001' directo en la tabla: HM-0001 -> -2
DECLARE
    v_precio NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    DBMS_OUTPUT.PUT_LINE('HM-0001 ......... ' || FN_PRECIO_PRODUCTO('HM-0001'));
    DBMS_OUTPUT.PUT_LINE('" hm-0002 " ..... ' || FN_PRECIO_PRODUCTO(' hm-0002 '));
    v_precio := FN_PRECIO_PRODUCTO('ZZ-9999');
    DBMS_OUTPUT.PUT_LINE('ZZ-9999 ......... ' || v_precio);

    -- Simulacion de una carga directa que no normaliza el codigo:
    -- la UK acepta 'hm-0001' porque es distinto de 'HM-0001'.
    INSERT INTO PRODUCTO (id_producto, codigo, nombre, id_categoria,
                          precio_unitario, costo_unitario, stock_minimo, activo)
    VALUES (SEQ_PRODUCTO.NEXTVAL, 'hm-0001', 'Martillo cargado por migracion', 1,
            45000, 28000, 20, 'S');
    DBMS_OUTPUT.PUT_LINE('Insertado directamente el codigo "hm-0001" (la UK lo acepto).');
    v_precio := FN_PRECIO_PRODUCTO('HM-0001');
    DBMS_OUTPUT.PUT_LINE('HM-0001 ......... ' || v_precio);
    ROLLBACK;
END;
/

------------------------------------------------------------------- 4.2 (2 pts)
-- SP_VALIDAR_DESPACHO
-- Procedimiento que verifique si puede despacharse una cantidad de un producto
-- desde una bodega. Debe declarar una EXCEPCION PROPIA, levantarla con RAISE
-- cuando la cantidad solicitada supere el disponible, y capturarla en el bloque
-- EXCEPTION.
-- Argumente por que conviene nombrar esa condicion en lugar de resolverla con un
-- condicional.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- POR QUE NOMBRAR LA CONDICION: e_stock_insuficiente separa DETECTAR la
-- condicion de TRATARLA. El cuerpo se lee como el camino normal ("si alcanza,
-- se aprueba") y todo el tratamiento del caso anomalo queda en un solo
-- manejador. Si mas adelante hay varios puntos que detectan insuficiencia
-- (por bodega, por reserva, por lote), todos hacen RAISE de la misma excepcion
-- y convergen en el mismo tratamiento, en lugar de repetir el mensaje y la
-- accion en cada IF. Ademas el RAISE corta el flujo: con un IF, el codigo que
-- sigue podria ejecutarse por error si falta un ELSE o un RETURN.
-- El nombre documenta la regla: "WHEN e_stock_insuficiente" se entiende sin
-- leer la comparacion.
-- DECISIONES:
-- 1) El disponible se obtiene con FN_STOCK_DISPONIBLE (2.1): la definicion de
--    "disponible" (bodegas activas) vive en un solo lugar.
-- 2) El manejador informa y ademas relanza como -20030: si solo imprimiera,
--    quien llama no tendria forma programatica de saber que la validacion
--    fallo (el procedimiento no tiene parametros OUT). Se usa el mismo codigo
--    que SP_AJUSTAR_STOCK y el trigger 5.4 para la misma condicion.
-- ANALISIS OPERACIONAL: la validacion no RESERVA el stock. Entre validar y
-- despachar otra sesion puede consumirlo (verificar-y-luego-actuar). Por eso
-- la garantia real esta donde se descuenta: SP_AJUSTAR_STOCK (FOR UPDATE) y
-- el trigger 5.4 (UPDATE condicional atomico). Este SP sirve para responder
-- rapido al usuario, no para asegurar el despacho.
--
CREATE OR REPLACE PROCEDURE SP_VALIDAR_DESPACHO (
    p_id_producto IN NUMBER,
    p_id_bodega   IN NUMBER,
    p_cantidad    IN NUMBER
) IS
    e_stock_insuficiente  EXCEPTION;
    v_disponible          NUMBER;
BEGIN
    IF p_id_bodega IS NULL THEN
        RAISE_APPLICATION_ERROR(-20114, 'Debe indicar la bodega desde la que se despacha.');
    END IF;
    IF p_cantidad IS NULL OR p_cantidad <= 0 THEN
        RAISE_APPLICATION_ERROR(-20112, 'La cantidad a despachar debe ser positiva.');
    END IF;

    v_disponible := FN_STOCK_DISPONIBLE(p_id_producto, p_id_bodega);

    IF p_cantidad > v_disponible THEN
        RAISE e_stock_insuficiente;
    END IF;

    DBMS_OUTPUT.PUT_LINE('Despacho VIABLE: producto ' || p_id_producto || ', bodega ' || p_id_bodega ||
                         ', solicitado ' || p_cantidad || ', disponible ' || v_disponible || '.');
EXCEPTION
    WHEN e_stock_insuficiente THEN
        DBMS_OUTPUT.PUT_LINE('Despacho NO VIABLE: producto ' || p_id_producto || ', bodega ' ||
                             p_id_bodega || ', solicitado ' || p_cantidad ||
                             ', disponible ' || v_disponible || ', faltan ' ||
                             (p_cantidad - v_disponible) || '.');
        RAISE_APPLICATION_ERROR(-20030,
            'Stock insuficiente para despachar ' || p_cantidad || ' unidades del producto ' ||
            p_id_producto || ' desde la bodega ' || p_id_bodega || '.');
END SP_VALIDAR_DESPACHO;
/

-- EVIDENCIA 4.2
-- RESULTADO ESPERADO: 1001/B1 50 viable | 1005/B1 10 no viable (hay 4) ->
-- -20030 | 1011/B2 1 no viable (hay 0) -> -20030
DECLARE
    PROCEDURE probar (p_prod NUMBER, p_bod NUMBER, p_cant NUMBER) IS
    BEGIN
        SP_VALIDAR_DESPACHO(p_prod, p_bod, p_cant);
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('   -> el llamador recibe SQLCODE ' || SQLCODE || ': ' || SQLERRM);
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    probar(1001, 1, 50);
    probar(1005, 1, 10);
    probar(1011, 2,  1);
END;
/

------------------------------------------------------------------- 4.3 (2 pts)
-- SP_ANULAR_PEDIDO
-- Procedimiento que anule un pedido, usando RAISE_APPLICATION_ERROR con estos
-- codigos:
--     -20010  el pedido no existe
--     -20011  el pedido ya esta anulado
--     -20012  el pedido tiene mas de 30 dias
-- Explique la diferencia entre RAISE y RAISE_APPLICATION_ERROR, y en que caso el
-- cliente de la base de datos puede distinguirlos.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- RAISE vs RAISE_APPLICATION_ERROR:
-- * RAISE levanta una excepcion con NOMBRE (predefinida o declarada). Sirve
--   dentro de PL/SQL: otro bloque la captura por su nombre. Si una excepcion
--   de usuario sale sin manejar hasta el cliente, este solo recibe
--   ORA-06510 "unhandled user-defined exception" (SQLCODE 1 en PL/SQL): el
--   nombre y el motivo se pierden en la frontera.
-- * RAISE_APPLICATION_ERROR levanta un error Oracle con un NUMERO del rango
--   -20000..-20999 y un MENSAJE propio, que viajan hasta el cliente como
--   cualquier ORA-. Una aplicacion Java lee getErrorCode() = 20010 y decide.
-- * CUANDO EL CLIENTE LOS DISTINGUE: solo con RAISE_APPLICATION_ERROR (o con
--   excepciones predefinidas, que ya tienen numero ORA). Dos excepciones de
--   usuario distintas propagadas con RAISE llegan ambas como el mismo
--   ORA-06510. Por eso este SP, que sera llamado desde fuera, usa RAE.
-- DECISIONES:
-- 1) Orden: existencia, anulado, antiguedad. Un pedido anulado hace mas de 30
--    dias reporta -20011 (ya esta anulado), que describe su situacion real;
--    -20012 le haria creer al usuario que aun podria anularse.
-- 2) Dias por fecha calendario (TRUNC en ambos lados): "mas de 30 dias" no
--    debe depender de la hora en que se ejecute.
-- 3) SELECT ... FOR UPDATE WAIT 5 sobre el pedido: evita que dos sesiones lo
--    anulen a la vez (ambas verian BORRADOR y devolverian el stock dos veces)
--    o que se anule mientras se factura (la Parte 6 bloquea la misma fila).
-- 4) Anular no es solo cambiar el estado: las lineas ya descontaron stock
--    (trigger 5.4), asi que se devuelve con SP_AJUSTAR_STOCK (ENTRADA) en vez
--    de reescribir esa logica; y si estaba CONFIRMADO se descuenta su total
--    del saldo del cliente. GREATEST(...,0) protege a los pedidos cargados
--    por el script 01, cuyo total nunca se sumo al saldo.
-- 5) SAVEPOINT: si falla la devolucion de la linea 3, las lineas 1 y 2 ya
--    devueltas NO se deshacen solas cuando el error se captura en PL/SQL (la
--    atomicidad automatica es por llamada desde el cliente). Se vuelve al
--    savepoint y se relanza para no dejar una anulacion a medias.
--
CREATE OR REPLACE PROCEDURE SP_ANULAR_PEDIDO (
    p_id_pedido IN NUMBER
) IS
    v_estado   PEDIDO.estado%TYPE;
    v_fecha    PEDIDO.fecha_pedido%TYPE;
    v_total    PEDIDO.total%TYPE;
    v_cliente  PEDIDO.id_cliente%TYPE;
    v_dias     NUMBER;
    v_saldo    NUMBER;
BEGIN
    SAVEPOINT sp_anular_pedido;

    BEGIN
        SELECT estado, fecha_pedido, total, id_cliente
          INTO v_estado, v_fecha, v_total, v_cliente
          FROM PEDIDO
         WHERE id_pedido = p_id_pedido
           FOR UPDATE WAIT 5;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20010, 'El pedido ' || p_id_pedido || ' no existe.');
    END;

    IF v_estado = 'ANULADO' THEN
        RAISE_APPLICATION_ERROR(-20011, 'El pedido ' || p_id_pedido || ' ya esta anulado.');
    END IF;

    v_dias := TRUNC(SYSDATE) - TRUNC(v_fecha);
    IF v_dias > 30 THEN
        RAISE_APPLICATION_ERROR(-20012, 'El pedido ' || p_id_pedido || ' tiene ' || v_dias ||
                                ' dias; solo se anulan pedidos de 30 dias o menos.');
    END IF;

    FOR r IN (SELECT linea, id_producto, id_bodega, cantidad
                FROM DETALLE_PEDIDO
               WHERE id_pedido = p_id_pedido
               ORDER BY linea) LOOP
        SP_AJUSTAR_STOCK(r.id_producto, r.id_bodega, 'ENTRADA', r.cantidad,
                         'Reverso por anulacion del pedido ' || p_id_pedido || ' linea ' || r.linea,
                         v_saldo);
    END LOOP;

    IF v_estado = 'CONFIRMADO' THEN
        UPDATE CLIENTE
           SET saldo_pendiente = GREATEST(saldo_pendiente - v_total, 0)
         WHERE id_cliente = v_cliente;
    END IF;

    UPDATE PEDIDO SET estado = 'ANULADO' WHERE id_pedido = p_id_pedido;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK TO sp_anular_pedido;
        RAISE;
END SP_ANULAR_PEDIDO;
/

-- EVIDENCIA 4.3
-- RESULTADO ESPERADO: 999 -> -20010 | 7 -> -20011 | 1 -> -20012 (mas de 100
-- dias) | pedido nuevo del cliente 503 -> ANULADO. (La anulacion con devolucion
-- de stock y de saldo se evidencia en la Parte 6, escenario A.)
DECLARE
    v_nuevo NUMBER;
    PROCEDURE probar (p_desc VARCHAR2, p_pedido NUMBER) IS
        v_estado PEDIDO.estado%TYPE;
    BEGIN
        SP_ANULAR_PEDIDO(p_pedido);
        SELECT estado INTO v_estado FROM PEDIDO WHERE id_pedido = p_pedido;
        DBMS_OUTPUT.PUT_LINE(RPAD('OK        ' || p_desc, 40) || 'estado final: ' || v_estado);
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(RPAD('RECHAZADO ' || p_desc, 40) || 'SQLCODE ' || SQLCODE || ': ' || SQLERRM);
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    probar('Pedido 999 (no existe)',        999);
    probar('Pedido 7 (ya anulado)',           7);
    probar('Pedido 1 (del 2026-06-10)',       1);
    SP_CREAR_PEDIDO(503, v_nuevo);
    probar('Pedido ' || v_nuevo || ' creado hoy', v_nuevo);
    ROLLBACK;
END;
/

------------------------------------------------------------------- 4.4 (2 pts)
-- Bloque anonimo que intente insertar un producto con una categoria inexistente
-- y capture el error de integridad referencial asociando ORA-02291 a una
-- excepcion con nombre.
-- Explique que aporta esa asociacion frente a atrapar el error en un manejador
-- generico.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- ORA-02291 no tiene nombre predefinido en PL/SQL (a diferencia de
-- DUP_VAL_ON_INDEX). PRAGMA EXCEPTION_INIT le asigna uno en tiempo de
-- compilacion. Lo que aporta frente a WHEN OTHERS:
-- 1) PRECISION: el manejador atrapa SOLO la violacion de llave foranea. Un
--    WHEN OTHERS atraparia tambien un codigo duplicado (ORA-00001), una
--    violacion de CHECK o un error de espacio, y los trataria a todos como
--    "categoria inexistente": el diagnostico seria falso. Con el nombre, los
--    errores no previstos siguen propagandose y se ven.
-- 2) LEGIBILIDAD: "WHEN e_categoria_inexistente" expresa la regla de negocio;
--    "WHEN OTHERS THEN IF SQLCODE = -2291" obliga a conocer el numero y agrega
--    un IF que es facil olvidar (y sin el, se tragan todos los errores).
-- 3) El INSERT fallido no deja la fila: la atomicidad de sentencia la revierte
--    antes de llegar al manejador; no se necesita ROLLBACK.
-- Nota de integracion: el trigger 5.3 consulta CATEGORIA antes del INSERT. Se
-- diseno para NO interferir cuando la categoria no existe (ver 5.3), de modo
-- que este bloque sigue recibiendo ORA-02291 aun con los triggers creados.
--
DECLARE
    e_categoria_inexistente EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_categoria_inexistente, -2291);
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    INSERT INTO PRODUCTO (id_producto, codigo, nombre, id_categoria,
                          precio_unitario, costo_unitario, stock_minimo, activo)
    VALUES (SEQ_PRODUCTO.NEXTVAL, 'XX-0001', 'Producto con categoria inexistente', 99,
            50000, 30000, 5, 'S');
    DBMS_OUTPUT.PUT_LINE('No deberia llegar aqui: el producto se inserto.');
EXCEPTION
    WHEN e_categoria_inexistente THEN
        DBMS_OUTPUT.PUT_LINE('Capturada e_categoria_inexistente (SQLCODE ' || SQLCODE || ').');
        DBMS_OUTPUT.PUT_LINE('Mensaje del motor: ' || SQLERRM);
        DBMS_OUTPUT.PUT_LINE('La categoria 99 no existe en CATEGORIA; el producto no se registro.');
END;
/

------------------------------------------------------------------- 4.5 (1 pt)
-- SP_REGISTRAR_ERROR
-- Procedimiento que reciba el origen y registre en LOG_ERRORES el SQLCODE y el
-- SQLERRM actuales. El registro debe persistir aunque la transaccion principal
-- termine en ROLLBACK.
-- Explique por que se requiere esa independencia transaccional y describa un
-- escenario en el que esa misma independencia oculte informacion en lugar de
-- preservarla.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- POR QUE LA INDEPENDENCIA: el log se escribe justo cuando algo fallo, y lo
-- normal despues de un fallo es ROLLBACK. Si el INSERT en LOG_ERRORES fuera
-- parte de la transaccion principal, ese ROLLBACK borraria tambien el
-- registro del error: el log desapareceria precisamente cuando se necesita.
-- PRAGMA AUTONOMOUS_TRANSACTION ejecuta el procedimiento en una transaccion
-- propia; su COMMIT confirma solo el INSERT del log, sin confirmar ni revertir
-- nada de la transaccion que lo llamo. El COMMIT es obligatorio: una
-- transaccion autonoma que termina con cambios pendientes da ORA-06519.
--
-- ESCENARIO EN QUE OCULTA INFORMACION: la transaccion autonoma NO ve los
-- cambios sin confirmar de la transaccion principal. Si el log intentara
-- registrar contexto, por ejemplo "total del pedido y saldo del cliente al
-- fallar la facturacion", leeria la ultima version CONFIRMADA: el saldo de
-- antes y el pedido todavia en su estado anterior, no los valores que la
-- transaccion principal tenia en ese momento y que provocaron el error. El log
-- quedaria persistente y creible, pero describiendo un estado que no fue el del
-- fallo. Por eso aqui el contexto se pasa POR PARAMETRO (p_detalle) desde
-- quien si lo ve, en lugar de consultarlo dentro del log.
-- Un segundo riesgo: si la autonoma intenta modificar una fila que la
-- principal tiene bloqueada, espera a una transaccion que a su vez la espera a
-- ella (bloqueo mutuo, ORA-00060) y el error original queda sin registrar.
--
-- DECISIONES:
-- 1) SQLCODE y SQLERRM se copian a variables en la primera linea, antes de
--    ejecutar cualquier otra cosa.
-- 2) Se agrega DBMS_UTILITY.FORMAT_ERROR_BACKTRACE (linea donde nacio el error)
--    al detalle, porque SQLERRM dice QUE fallo pero no DONDE.
-- 3) El manejador WHEN OTHERS del propio log hace ROLLBACK y no relanza: si
--    falla el registro (tabla llena, por ejemplo), el error del log no debe
--    reemplazar al error original que el llamador esta por relanzar. Es el
--    unico WHEN OTHERS sin RAISE del taller y es deliberado.
--
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_ERROR (
    p_origen  IN VARCHAR2,
    p_detalle IN VARCHAR2 DEFAULT NULL
) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    v_codigo   NUMBER;
    v_mensaje  VARCHAR2(500);
    v_detalle  VARCHAR2(500);
BEGIN
    v_codigo  := SQLCODE;
    v_mensaje := SUBSTR(SQLERRM, 1, 500);
    v_detalle := SUBSTR(p_detalle ||
                        CASE WHEN p_detalle IS NOT NULL THEN ' | ' END ||
                        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 500);

    INSERT INTO LOG_ERRORES (id_log, origen, codigo_error, mensaje, detalle, usuario_bd, fecha_log)
    VALUES (SEQ_LOG.NEXTVAL, SUBSTR(NVL(p_origen, 'DESCONOCIDO'), 1, 60),
            v_codigo, v_mensaje, v_detalle, USER, SYSTIMESTAMP);
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ADVERTENCIA: no se pudo registrar el error en LOG_ERRORES: ' || SQLERRM);
END SP_REGISTRAR_ERROR;
/

-- EVIDENCIA 4.5
-- RESULTADO ESPERADO: la transaccion principal cambia el cupo del 501 y luego
-- falla (ORA-00001). Tras el ROLLBACK el cupo vuelve a 8000000, pero
-- LOG_ERRORES tiene una fila mas con codigo -1.
DECLARE
    v_log_antes  NUMBER;
    v_log_desp   NUMBER;
    v_cupo       CLIENTE.cupo_credito%TYPE;
    v_origen     LOG_ERRORES.origen%TYPE;
    v_codigo     LOG_ERRORES.codigo_error%TYPE;
    v_mensaje    LOG_ERRORES.mensaje%TYPE;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    SELECT COUNT(*) INTO v_log_antes FROM LOG_ERRORES;

    BEGIN
        UPDATE CLIENTE SET cupo_credito = cupo_credito + 1000000 WHERE id_cliente = 501;
        SELECT cupo_credito INTO v_cupo FROM CLIENTE WHERE id_cliente = 501;
        DBMS_OUTPUT.PUT_LINE('Cupo 501 dentro de la transaccion principal: ' || v_cupo);
        INSERT INTO PEDIDO (id_pedido, id_cliente) VALUES (1, 501);   -- PK duplicada
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            SP_REGISTRAR_ERROR('EVIDENCIA 4.5', 'Insercion de pedido con id duplicado');
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('Error registrado y transaccion principal revertida (ROLLBACK).');
    END;

    SELECT cupo_credito INTO v_cupo FROM CLIENTE WHERE id_cliente = 501;
    SELECT COUNT(*) INTO v_log_desp FROM LOG_ERRORES;
    SELECT origen, codigo_error, mensaje INTO v_origen, v_codigo, v_mensaje
      FROM LOG_ERRORES WHERE id_log = (SELECT MAX(id_log) FROM LOG_ERRORES);

    DBMS_OUTPUT.PUT_LINE('Cupo 501 despues del ROLLBACK: ' || v_cupo || ' (el cambio se revirtio)');
    DBMS_OUTPUT.PUT_LINE('Filas en LOG_ERRORES: antes ' || v_log_antes || ', despues ' || v_log_desp ||
                         ' (el registro persistio)');
    DBMS_OUTPUT.PUT_LINE('Ultimo registro: origen=' || v_origen || ' codigo=' || v_codigo);
    DBMS_OUTPUT.PUT_LINE('                 mensaje=' || v_mensaje);
END;
/


--==============================================================================
-- PARTE 5 — DISPARADORES                                     (10 puntos / 90 min)
--==============================================================================
-- Los esqueletos de esta parte no incluyen la clausula de disparo. Definirla
-- hace parte del ejercicio.
--==============================================================================

------------------------------------------------------------------- 5.1 (2 pts)
-- TRG_CLIENTE_BI
-- Al insertar un cliente debe asignar el identificador desde SEQ_CLIENTE si
-- llega nulo, convertir el nombre a mayusculas sin espacios sobrantes y forzar
-- el estado activo a 'S' si no se indica.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) BEFORE y FOR EACH ROW: hay que MODIFICAR :NEW antes de que la fila se
--    escriba y se validen las restricciones. En AFTER, :NEW ya no se puede
--    asignar; y a nivel de sentencia no existe :NEW.
-- 2) Solo se asigna el id si llega nulo: una migracion que trae sus propios
--    ids debe poder conservarlos. La secuencia quedo sincronizada en la
--    PREPARACION; no se consulta CLIENTE dentro del trigger para "saltar" ids
--    ocupados porque un INSERT ... SELECT sobre CLIENTE haria mutante la tabla
--    (ORA-04091) y cada fila pagaria una consulta extra.
-- 3) "Sin espacios sobrantes" incluye los internos: 'FERRETERIA    EL  SOL'
--    se compacta a un espacio con REGEXP_REPLACE y luego TRIM quita extremos.
--    Solo TRIM dejaria nombres que parecen iguales pero no lo son.
-- 4) Sobre activo: si la columna se OMITE en el INSERT, el DEFAULT 'S' ya se
--    aplica antes del trigger. El trigger es necesario cuando se envia NULL
--    EXPLICITO (VALUES (..., NULL)): ahi el DEFAULT no actua y la fila
--    fallaria por NOT NULL. Tambien se normaliza 's' a 'S' para que el CHECK
--    no rechace un valor que el usuario quiso decir bien.
--
CREATE OR REPLACE TRIGGER TRG_CLIENTE_BI
BEFORE INSERT ON CLIENTE
FOR EACH ROW
BEGIN
    IF :NEW.id_cliente IS NULL THEN
        :NEW.id_cliente := SEQ_CLIENTE.NEXTVAL;
    END IF;

    :NEW.nombre := UPPER(TRIM(REGEXP_REPLACE(:NEW.nombre, '[[:space:]]+', ' ')));
    :NEW.activo := NVL(UPPER(TRIM(:NEW.activo)), 'S');
END TRG_CLIENTE_BI;
/

-- EVIDENCIA 5.1
-- RESULTADO ESPERADO: dos clientes con id asignado por secuencia (508, 509 en
-- la primera ejecucion), nombres en mayusculas con un solo espacio y activo 'S'.
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    -- id y activo enviados como NULL explicito
    INSERT INTO CLIENTE (id_cliente, documento, nombre, ciudad, cupo_credito, saldo_pendiente, activo)
    VALUES (NULL, '901000001', '   ferreteria    el   tornillo  ', 'Tunja', 1000000, 0, NULL);
    -- id y activo omitidos
    INSERT INTO CLIENTE (documento, nombre, ciudad, cupo_credito)
    VALUES ('901000002', 'Distribuciones   la  Llave sas', 'Pasto', 500000);

    FOR c IN (SELECT id_cliente, documento, nombre, activo FROM CLIENTE
               WHERE documento IN ('901000001', '901000002') ORDER BY documento) LOOP
        DBMS_OUTPUT.PUT_LINE('id=' || c.id_cliente || '  doc=' || c.documento ||
                             '  nombre="' || c.nombre || '"  activo=' || c.activo);
    END LOOP;
    ROLLBACK;
END;
/

------------------------------------------------------------------- 5.2 (2 pts)
-- TRG_PRODUCTO_AU_PRECIO
-- Debe registrar en AUDITORIA_PRECIO todo cambio de precio, calculando la
-- variacion porcentual, y dispararse unicamente cuando el precio efectivamente
-- cambie, resolviendo esa condicion con la clausula WHEN y no dentro del cuerpo.
-- Explique la diferencia entre ambas formas.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- DIFERENCIA WHEN vs IF EN EL CUERPO: la clausula WHEN la evalua el motor SQL
-- ANTES de invocar el trigger; si es falsa, el cuerpo PL/SQL no se ejecuta
-- (no hay cambio de contexto ni se instancia el bloque). Con un IF en el
-- cuerpo el trigger se ejecuta SIEMPRE, por cada fila, y recien adentro decide
-- no hacer nada. En un UPDATE de 100.000 filas donde el precio cambia en 10,
-- WHEN ejecuta el cuerpo 10 veces; el IF, 100.000. Ademas WHEN deja la regla
-- de disparo visible en la definicion (USER_TRIGGERS.WHEN_CLAUSE), no
-- escondida en el codigo. Limites: WHEN solo existe en triggers de fila y
-- referencia NEW/OLD sin los dos puntos.
-- DOS FILTROS COMPLEMENTARIOS:
-- * "UPDATE OF precio_unitario": sentencias que no nombran la columna (p. ej.
--   el FORALL de 3.5 sobre stock_minimo) ni siquiera consideran el trigger.
-- * WHEN (NEW <> OLD): descarta los UPDATE que nombran la columna pero dejan
--   el mismo valor (como hace el trigger 5.6 al actualizar la vista). No hace
--   falta tratar NULL porque la columna es NOT NULL.
-- OTRAS DECISIONES:
-- 1) AFTER: se audita un cambio que ya paso todas las validaciones (incluido
--    el margen del trigger 5.3, que es BEFORE). En BEFORE se podria auditar un
--    cambio que luego es rechazado.
-- 2) La division por :OLD.precio_unitario es segura: CK_PRODUCTO_PRECIO
--    garantiza precio > 0.
-- 3) La auditoria NO es autonoma (a diferencia de 4.5): si el UPDATE se
--    revierte, su auditoria tambien debe desaparecer; auditar un cambio que
--    nunca se confirmo seria falso.
--
CREATE OR REPLACE TRIGGER TRG_PRODUCTO_AU_PRECIO
AFTER UPDATE OF precio_unitario ON PRODUCTO
FOR EACH ROW
WHEN (NEW.precio_unitario <> OLD.precio_unitario)
BEGIN
    INSERT INTO AUDITORIA_PRECIO (id_auditoria, id_producto, precio_anterior, precio_nuevo,
                                  variacion_pct, usuario_bd, fecha_cambio)
    VALUES (SEQ_AUDITORIA.NEXTVAL, :NEW.id_producto, :OLD.precio_unitario, :NEW.precio_unitario,
            ROUND((:NEW.precio_unitario - :OLD.precio_unitario) / :OLD.precio_unitario * 100, 2),
            USER, SYSDATE);
END TRG_PRODUCTO_AU_PRECIO;
/

-- EVIDENCIA 5.2
-- RESULTADO ESPERADO: cambio real 45000 -> 48600 genera 1 auditoria (+8%);
-- mismo precio: 0; cambio de stock_minimo: 0. Total 1.
DECLARE
    v_n NUMBER;
    PROCEDURE contar (p_desc VARCHAR2) IS
    BEGIN
        SELECT COUNT(*) INTO v_n FROM AUDITORIA_PRECIO WHERE id_producto = 1001;
        DBMS_OUTPUT.PUT_LINE(RPAD(p_desc, 50) || 'auditorias de 1001: ' || v_n);
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    contar('Estado inicial');
    UPDATE PRODUCTO SET precio_unitario = 48600 WHERE id_producto = 1001;
    contar('UPDATE precio 45000 -> 48600');
    UPDATE PRODUCTO SET precio_unitario = 48600 WHERE id_producto = 1001;
    contar('UPDATE precio con el mismo valor');
    UPDATE PRODUCTO SET stock_minimo = 30 WHERE id_producto = 1001;
    contar('UPDATE solo de stock_minimo');
    FOR a IN (SELECT id_auditoria, precio_anterior, precio_nuevo, variacion_pct, usuario_bd
                FROM AUDITORIA_PRECIO WHERE id_producto = 1001) LOOP
        DBMS_OUTPUT.PUT_LINE('Auditoria #' || a.id_auditoria || ': ' || a.precio_anterior || ' -> ' ||
                             a.precio_nuevo || ' (' || a.variacion_pct || '%) por ' || a.usuario_bd);
    END LOOP;
    ROLLBACK;
END;
/

------------------------------------------------------------------- 5.3 (2 pts)
-- TRG_PRODUCTO_BIU_MARGEN
-- Debe impedir que se guarde un producto cuyo precio no alcance el margen minimo
-- de su categoria, segun la formula precio >= costo * (1 + margen/100),
-- rechazando la operacion con el error -20020.
-- Considere que debe ocurrir cuando la categoria indicada no existe, y justifique
-- su decision.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- 1) BEFORE INSERT OR UPDATE: la validacion debe impedir la escritura; en
--    BEFORE la fila aun no se escribio, y el error aborta la sentencia.
-- 2) "UPDATE OF precio_unitario, costo_unitario, id_categoria": son las tres
--    columnas de la formula. Cambiar el nombre o el stock minimo no puede
--    romper el margen, asi que no hay por que consultar CATEGORIA.
-- 3) CATEGORIA INEXISTENTE -> EL TRIGGER NO HACE NADA y deja que la FK
--    rechace con ORA-02291. Razones:
--    * Sin margen no se puede evaluar la regla; rechazar con -20020 diria
--      "no alcanza el margen", una causa falsa.
--    * Dejar escapar NO_DATA_FOUND produciria ORA-01403 + ORA-04088 ("error
--      durante la ejecucion del trigger"): el usuario veria un error del
--      trigger en lugar del problema real.
--    * La existencia de la categoria ya tiene un responsable: la FK. Duplicar
--      esa regla con otro codigo haria que la misma falla se reporte distinto
--      segun por donde entre. Asi 4.4 recibe ORA-02291 con o sin trigger.
--    El manejador captura solo NO_DATA_FOUND del SELECT; el -20020 no se ve
--    afectado porque RAISE_APPLICATION_ERROR no es NO_DATA_FOUND.
-- 4) Consultar CATEGORIA desde un trigger de fila de PRODUCTO no produce tabla
--    mutante: la tabla que muta es PRODUCTO.
-- ANALISIS OPERACIONAL: el trigger valida al escribir el PRODUCTO. Si despues
-- se SUBE el margen de una categoria, los productos existentes pueden quedar
-- bajo el nuevo minimo sin que nadie lo detecte; eso requeriria validar tambien
-- al actualizar CATEGORIA. En volumen, cada fila hace una lectura por PK de
-- CATEGORIA (5 filas, siempre en cache).
--
CREATE OR REPLACE TRIGGER TRG_PRODUCTO_BIU_MARGEN
BEFORE INSERT OR UPDATE OF precio_unitario, costo_unitario, id_categoria ON PRODUCTO
FOR EACH ROW
DECLARE
    v_margen  CATEGORIA.margen_minimo%TYPE;
    v_minimo  NUMBER;
BEGIN
    SELECT margen_minimo
      INTO v_margen
      FROM CATEGORIA
     WHERE id_categoria = :NEW.id_categoria;

    v_minimo := :NEW.costo_unitario * (1 + v_margen / 100);

    IF :NEW.precio_unitario < v_minimo THEN
        RAISE_APPLICATION_ERROR(-20020,
            'Producto ' || :NEW.codigo || ': el precio ' || :NEW.precio_unitario ||
            ' no alcanza el minimo ' || v_minimo || ' (costo ' || :NEW.costo_unitario ||
            ' + margen ' || v_margen || '% de la categoria ' || :NEW.id_categoria || ').');
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        NULL;   -- categoria inexistente: decide la FK (ORA-02291). Ver justificacion.
END TRG_PRODUCTO_BIU_MARGEN;
/

-- EVIDENCIA 5.3
-- RESULTADO ESPERADO: 1004 a 250000 -> -20020 (minimo 289100) | alta via SP con
-- precio 12000 costo 10000 (cat 4, 35%) -> el SP lo acepta pero el trigger lo
-- rechaza con -20020 | categoria 99 -> ORA-02291 | 1004 a 300000 -> OK
DECLARE
    v_id NUMBER;
    PROCEDURE informar (p_desc VARCHAR2, p_error VARCHAR2 DEFAULT NULL) IS
    BEGIN
        IF p_error IS NULL THEN
            DBMS_OUTPUT.PUT_LINE(RPAD('OK        ' || p_desc, 46));
        ELSE
            DBMS_OUTPUT.PUT_LINE(RPAD('RECHAZADO ' || p_desc, 46) || p_error);
        END IF;
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    BEGIN
        UPDATE PRODUCTO SET precio_unitario = 250000 WHERE id_producto = 1004;
        informar('UPDATE 1004 precio 250000');
    EXCEPTION WHEN OTHERS THEN informar('UPDATE 1004 precio 250000', SQLERRM);
    END;
    BEGIN
        SP_REGISTRAR_PRODUCTO('FG-0200', 'Prueba margen', 4, 12000, 10000, 5, v_id);
        informar('SP_REGISTRAR_PRODUCTO 12000/10000 cat 4');
    EXCEPTION WHEN OTHERS THEN informar('SP_REGISTRAR_PRODUCTO 12000/10000 cat 4', SQLERRM);
    END;
    BEGIN
        INSERT INTO PRODUCTO (id_producto, codigo, nombre, id_categoria,
                              precio_unitario, costo_unitario, stock_minimo, activo)
        VALUES (SEQ_PRODUCTO.NEXTVAL, 'XX-0002', 'Categoria inexistente', 99, 50000, 30000, 5, 'S');
        informar('INSERT con categoria 99');
    EXCEPTION WHEN OTHERS THEN informar('INSERT con categoria 99', SQLERRM);
    END;
    BEGIN
        UPDATE PRODUCTO SET precio_unitario = 300000 WHERE id_producto = 1004;
        informar('UPDATE 1004 precio 300000');
    EXCEPTION WHEN OTHERS THEN informar('UPDATE 1004 precio 300000', SQLERRM);
    END;
    ROLLBACK;
END;
/

------------------------------------------------------------------- 5.4 (2 pts)
-- TRG_DETALLE_AI_STOCK
-- Al insertar una linea de pedido debe descontar el stock de la bodega indicada
-- y registrar el movimiento de SALIDA correspondiente. Si no hay stock suficiente
-- debe abortar la operacion con el error -20030.
-- Explique por que el momento de disparo que eligio es el correcto y que dejaria
-- de funcionar con el contrario.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- POR QUE AFTER: en un INSERT, Oracle ejecuta el trigger BEFORE de la fila,
-- luego escribe la fila y verifica sus restricciones (PK de la linea, FK a
-- pedido/producto/bodega, CHECK cantidad > 0) y recien despues ejecuta el
-- AFTER. En AFTER, :NEW es la version definitiva y ya valida de la linea: se
-- descuenta exactamente lo que quedo guardado.
-- QUE DEJARIA DE FUNCIONAR EN BEFORE:
-- 1) Diagnostico: una linea con producto inexistente, bodega inexistente o
--    numero de linea repetido pasaria primero por el trigger, que no
--    encontraria existencia y responderia -20030 "stock insuficiente". El
--    usuario recibiria una causa falsa en lugar de ORA-02291 o ORA-00001.
-- 2) Valor definitivo: en BEFORE, :NEW todavia puede ser modificado por otro
--    trigger BEFORE de la misma tabla (el orden entre triggers del mismo
--    momento no esta garantizado sin FOLLOWS). Se podria descontar una
--    cantidad distinta de la que finalmente se guarda.
-- Aclaracion: el argumento NO es que en BEFORE "quede descontado el stock si
-- la linea falla": cualquier error aborta la sentencia completa y Oracle
-- revierte tambien lo hecho por el trigger. La diferencia es de diagnostico y
-- de valor definitivo, no de atomicidad. AFTER tambien alcanza para abortar:
-- -20030 levantado aqui revierte la linea recien insertada.
-- CONCURRENCIA: el descuento es un UPDATE condicional
-- "SET cantidad = cantidad - n WHERE ... AND cantidad >= n". Oracle bloquea la
-- fila y reevalua la condicion con el valor vigente, asi que dos sesiones que
-- despachan a la vez no pueden dejar el saldo negativo: la segunda ve el saldo
-- ya descontado y, si no alcanza, actualiza 0 filas -> -20030. Una sola
-- sentencia reemplaza la secuencia leer-validar-escribir.
-- POR QUE NO LLAMA A SP_AJUSTAR_STOCK: el movimiento debe quedar ligado a
-- id_pedido (como en los datos cargados) y la firma del SP, fijada por la
-- plantilla, no tiene ese parametro.
-- LIMITACION: el enunciado cubre el INSERT. Modificar o borrar una linea no
-- ajusta el stock; la devolucion se hace al anular el pedido (4.3).
--
CREATE OR REPLACE TRIGGER TRG_DETALLE_AI_STOCK
AFTER INSERT ON DETALLE_PEDIDO
FOR EACH ROW
DECLARE
    v_saldo EXISTENCIA.cantidad%TYPE;
BEGIN
    UPDATE EXISTENCIA
       SET cantidad = cantidad - :NEW.cantidad
     WHERE id_bodega   = :NEW.id_bodega
       AND id_producto = :NEW.id_producto
       AND cantidad   >= :NEW.cantidad
    RETURNING cantidad INTO v_saldo;

    IF SQL%ROWCOUNT = 0 THEN
        RAISE_APPLICATION_ERROR(-20030,
            'Stock insuficiente para la linea ' || :NEW.linea || ' del pedido ' || :NEW.id_pedido ||
            ': producto ' || :NEW.id_producto || ', bodega ' || :NEW.id_bodega ||
            ', solicitado ' || :NEW.cantidad ||
            ', disponible ' || FN_STOCK_DISPONIBLE(:NEW.id_producto, :NEW.id_bodega) || '.');
    END IF;

    INSERT INTO MOVIMIENTO_INVENTARIO (id_movimiento, id_producto, id_bodega, tipo,
                                       cantidad, fecha_mov, id_pedido, observacion)
    VALUES (SEQ_MOVIMIENTO.NEXTVAL, :NEW.id_producto, :NEW.id_bodega, 'SALIDA',
            :NEW.cantidad, SYSDATE, :NEW.id_pedido,
            'Despacho de pedido, linea ' || :NEW.linea || ', saldo resultante ' || v_saldo);
END TRG_DETALLE_AI_STOCK;
/

-- EVIDENCIA 5.4
-- RESULTADO ESPERADO: 1013/B1 pasa de 210 a 200 y se crea una SALIDA de 10
-- ligada al pedido; la linea de 50 unidades de 1005/B1 (hay 4) se rechaza con
-- -20030 y no queda guardada (el pedido conserva 1 linea).
DECLARE
    v_ped    NUMBER;
    v_lineas NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    SP_CREAR_PEDIDO(503, v_ped);
    DBMS_OUTPUT.PUT_LINE('Pedido de prueba: ' || v_ped);
    DBMS_OUTPUT.PUT_LINE('Stock 1013 en bodega 1 antes: ' || FN_STOCK_DISPONIBLE(1013, 1));

    INSERT INTO DETALLE_PEDIDO (id_pedido, linea, id_producto, id_bodega, cantidad, precio_unitario, subtotal)
    VALUES (v_ped, 1, 1013, 1, 10, 14500, 145000);
    DBMS_OUTPUT.PUT_LINE('Linea 1 insertada (10 und). Stock 1013 en bodega 1 despues: ' ||
                         FN_STOCK_DISPONIBLE(1013, 1));

    FOR m IN (SELECT id_movimiento, tipo, cantidad, id_pedido, observacion
                FROM MOVIMIENTO_INVENTARIO WHERE id_pedido = v_ped) LOOP
        DBMS_OUTPUT.PUT_LINE('Movimiento #' || m.id_movimiento || ' ' || m.tipo || ' ' || m.cantidad ||
                             ' pedido ' || m.id_pedido || ' - ' || m.observacion);
    END LOOP;

    BEGIN
        INSERT INTO DETALLE_PEDIDO (id_pedido, linea, id_producto, id_bodega, cantidad, precio_unitario, subtotal)
        VALUES (v_ped, 2, 1005, 1, 50, 285000, 14250000);
        DBMS_OUTPUT.PUT_LINE('Linea 2 insertada (no deberia).');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Linea 2 rechazada: ' || SQLERRM);
    END;

    SELECT COUNT(*) INTO v_lineas FROM DETALLE_PEDIDO WHERE id_pedido = v_ped;
    DBMS_OUTPUT.PUT_LINE('Lineas guardadas en el pedido: ' || v_lineas ||
                         ' | stock 1005 en bodega 1 intacto: ' || FN_STOCK_DISPONIBLE(1005, 1));
    ROLLBACK;
END;
/

------------------------------------------------------------------- 5.5 (1 pt)
-- TRG_DETALLE_TOTAL
-- Debe recalcular el total de la cabecera del pedido despues de cualquier
-- insercion, actualizacion o borrado de sus lineas.
-- Documente el error que obtiene en su primer intento, en que momento aparece,
-- y como lo resuelve la construccion que finalmente utilizo.
-- Este punto no se califica sin esa explicacion.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- PRIMER INTENTO: un trigger AFTER ... FOR EACH ROW (TRG_DETALLE_TOTAL_V1,
-- abajo) que por cada fila hace SUM(subtotal) sobre DETALLE_PEDIDO y actualiza
-- PEDIDO. Es la solucion "natural" porque en la fila se conoce el id_pedido.
--
-- ERROR OBTENIDO: ORA-04091: table <esquema>.DETALLE_PEDIDO is mutating,
-- trigger/function may not see it, acompanado de ORA-06512 y ORA-04088.
--
-- EN QUE MOMENTO APARECE: NO al compilar (CREATE TRIGGER termina sin errores,
-- porque la sintaxis es valida), sino al EJECUTAR un DML sobre DETALLE_PEDIDO.
-- La evidencia lo muestra en las dos pruebas: tanto el INSERT ... VALUES de una
-- sola fila (prueba A) como el UPDATE de 3 lineas (prueba B) terminan en
-- ORA-04091. Es decir, el error no depende de cuantas filas toque la sentencia:
-- aparece desde el primer DML. (La unica excepcion que Oracle contempla es un
-- trigger BEFORE de fila disparado por un INSERT ... VALUES de una fila; este
-- trigger es AFTER, asi que no queda cubierto.)
--
-- CAUSA (no confundir con el efecto): mientras una sentencia esta
-- modificando DETALLE_PEDIDO, la tabla esta en un estado intermedio: algunas
-- filas ya cambiaron y otras aun no. Si un trigger de FILA pudiera leerla, el
-- SUM dependeria del orden en que Oracle procesa las filas y daria un
-- resultado distinto segun ese orden. Oracle prohibe esa lectura para
-- garantizar un resultado determinista; ORA-04091 es el efecto de esa
-- prohibicion, no la causa del problema.
--
-- COMO LO RESUELVE EL COMPOUND TRIGGER: separa el trabajo en dos momentos de
-- un mismo trigger que comparten estado:
-- * AFTER EACH ROW: NO consulta DETALLE_PEDIDO; solo anota en una coleccion
--   que pedidos fueron afectados (:NEW y/o :OLD). Eso no es leer la tabla
--   mutante.
-- * AFTER STATEMENT: se ejecuta una vez cuando la sentencia termino; la tabla
--   ya no esta mutando y se puede sumar. Recalcula cada pedido una sola vez,
--   aunque la sentencia haya tocado 50 lineas del mismo pedido.
-- Frente a la alternativa clasica (paquete con variable global + trigger de
-- fila + trigger de sentencia), el compound trigger mantiene todo en un solo
-- objeto y su estado nace y muere con cada sentencia: si la sentencia falla,
-- no quedan pedidos "pendientes" en una variable de paquete para la siguiente.
--
-- DECISIONES:
-- 1) En UPDATE se anotan :OLD y :NEW: si una linea se mueve de pedido, cambian
--    los totales de ambos.
-- 2) La coleccion se indexa por VARCHAR2 porque id_pedido es NUMBER(10) y
--    puede superar el maximo de PLS_INTEGER (2.147.483.647). El indice ademas
--    elimina duplicados sin codigo adicional.
-- 3) Solo se recalculan pedidos en BORRADOR: el total de un pedido CONFIRMADO
--    ya incluye el descuento aplicado al facturar (Parte 6) y es un documento
--    contable; recalcularlo como suma bruta borraria ese descuento.
--
CREATE OR REPLACE TRIGGER TRG_DETALLE_TOTAL_V1
AFTER INSERT OR UPDATE OR DELETE ON DETALLE_PEDIDO
FOR EACH ROW
BEGIN
    UPDATE PEDIDO
       SET total = (SELECT NVL(SUM(subtotal), 0)
                      FROM DETALLE_PEDIDO
                     WHERE id_pedido = NVL(:NEW.id_pedido, :OLD.id_pedido))
     WHERE id_pedido = NVL(:NEW.id_pedido, :OLD.id_pedido);
END TRG_DETALLE_TOTAL_V1;
/

-- EVIDENCIA 5.5 (a) — primer intento: reproduccion del error
DECLARE
    v_ped NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    SP_CREAR_PEDIDO(503, v_ped);
    BEGIN
        INSERT INTO DETALLE_PEDIDO (id_pedido, linea, id_producto, id_bodega, cantidad, precio_unitario, subtotal)
        VALUES (v_ped, 1, 1014, 1, 2, 9500, 19000);
        DBMS_OUTPUT.PUT_LINE('Prueba A (INSERT ... VALUES de una fila): sin error.');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Prueba A (INSERT ... VALUES de una fila):');
            DBMS_OUTPUT.PUT_LINE(DBMS_UTILITY.FORMAT_ERROR_STACK);
    END;
    BEGIN
        UPDATE DETALLE_PEDIDO SET subtotal = subtotal WHERE id_pedido = 1;
        DBMS_OUTPUT.PUT_LINE('Prueba B (UPDATE de 3 lineas): sin error.');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Prueba B (UPDATE de 3 lineas):');
            DBMS_OUTPUT.PUT_LINE(DBMS_UTILITY.FORMAT_ERROR_STACK);
    END;
    ROLLBACK;
END;
/

DROP TRIGGER TRG_DETALLE_TOTAL_V1;

-- Construccion final:
CREATE OR REPLACE TRIGGER TRG_DETALLE_TOTAL
FOR INSERT OR UPDATE OR DELETE ON DETALLE_PEDIDO
COMPOUND TRIGGER

    TYPE t_pedidos IS TABLE OF BOOLEAN INDEX BY VARCHAR2(10);
    g_pedidos  t_pedidos;
    g_clave    VARCHAR2(10);

    AFTER EACH ROW IS
    BEGIN
        IF INSERTING OR UPDATING THEN
            g_pedidos(TO_CHAR(:NEW.id_pedido)) := TRUE;
        END IF;
        IF DELETING OR UPDATING THEN
            g_pedidos(TO_CHAR(:OLD.id_pedido)) := TRUE;
        END IF;
    END AFTER EACH ROW;

    AFTER STATEMENT IS
    BEGIN
        g_clave := g_pedidos.FIRST;
        WHILE g_clave IS NOT NULL LOOP
            UPDATE PEDIDO p
               SET p.total = (SELECT NVL(SUM(d.subtotal), 0)
                                FROM DETALLE_PEDIDO d
                               WHERE d.id_pedido = TO_NUMBER(g_clave))
             WHERE p.id_pedido = TO_NUMBER(g_clave)
               AND p.estado = 'BORRADOR';
            g_clave := g_pedidos.NEXT(g_clave);
        END LOOP;
        g_pedidos.DELETE;
    END AFTER STATEMENT;

END TRG_DETALLE_TOTAL;
/

-- EVIDENCIA 5.5 (b) — construccion final
-- RESULTADO ESPERADO: 0 -> 243000 (INSERT de 3 lineas en una sola sentencia,
-- el caso que en el primer intento fallaria) -> 288000 (UPDATE) -> 193000
-- (DELETE). Pedido 1 (CONFIRMADO) no cambia: 1286500.
DECLARE
    v_ped NUMBER;
    PROCEDURE mostrar (p_desc VARCHAR2, p_pedido NUMBER) IS
        v_total PEDIDO.total%TYPE;
    BEGIN
        SELECT total INTO v_total FROM PEDIDO WHERE id_pedido = p_pedido;
        DBMS_OUTPUT.PUT_LINE(RPAD(p_desc, 46) || 'total pedido ' || p_pedido || ' = ' || v_total);
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    SP_CREAR_PEDIDO(503, v_ped);
    mostrar('Pedido creado', v_ped);

    INSERT INTO DETALLE_PEDIDO (id_pedido, linea, id_producto, id_bodega, cantidad, precio_unitario, subtotal)
    SELECT v_ped, 1, 1001, 1,  2, 45000, 90000 FROM DUAL UNION ALL
    SELECT v_ped, 2, 1013, 1,  4, 14500, 58000 FROM DUAL UNION ALL
    SELECT v_ped, 3, 1014, 1, 10,  9500, 95000 FROM DUAL;
    mostrar('INSERT ... SELECT de 3 lineas', v_ped);

    UPDATE DETALLE_PEDIDO SET cantidad = 3, subtotal = 135000 WHERE id_pedido = v_ped AND linea = 1;
    mostrar('UPDATE linea 1 (2 -> 3 unidades)', v_ped);

    DELETE FROM DETALLE_PEDIDO WHERE id_pedido = v_ped AND linea = 3;
    mostrar('DELETE linea 3', v_ped);

    UPDATE DETALLE_PEDIDO SET subtotal = subtotal WHERE id_pedido = 1;
    mostrar('UPDATE sobre pedido CONFIRMADO (no se toca)', 1);
    ROLLBACK;
END;
/

------------------------------------------------------------------- 5.6 (1 pt)
-- TRG_V_STOCK_IO
-- Debe permitir actualizar el precio y el stock minimo del producto a traves de
-- la vista V_STOCK_CONSOLIDADO.
-- Explique por que esa vista no es actualizable de forma directa.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- POR QUE NO ES ACTUALIZABLE: Oracle solo actualiza una vista si cada fila de
-- la vista corresponde a UNA fila identificable de una tabla base (tabla
-- "key-preserved"). V_STOCK_CONSOLIDADO usa GROUP BY y SUM: cada fila de la
-- vista resume varias filas de EXISTENCIA, y stock_total no existe en ninguna
-- tabla, es un calculo. Ante un UPDATE, Oracle no tiene una fila base a la
-- cual dirigir el cambio (y para stock_total, no sabria en que bodega
-- repartirlo), por lo que responde ORA-01732 (operacion no valida en esta
-- vista). Que PRODUCTO sea la tabla principal del JOIN no alcanza: el GROUP BY
-- destruye la correspondencia uno a uno.
-- DECISIONES:
-- 1) INSTEAD OF UPDATE ... FOR EACH ROW: Oracle ejecuta el trigger EN LUGAR
--    del UPDATE sobre la vista, y el trigger traduce el cambio a la tabla que
--    realmente contiene el dato (PRODUCTO, por :OLD.id_producto).
-- 2) Si el UPDATE intenta cambiar otra columna (stock_total, codigo, nombre,
--    categoria, id) se rechaza con -20050 en lugar de ignorarla en silencio:
--    un usuario que "sube el stock" por la vista y recibe "1 fila actualizada"
--    creeria que lo hizo. El stock se mueve con SP_AJUSTAR_STOCK.
-- 3) La comparacion es segura ante NULL (funcion cambio): con "<>" un valor
--    puesto en NULL no se detectaria.
-- 4) El UPDATE sobre PRODUCTO dispara las reglas de la tabla real: el margen
--    (5.3) y la auditoria de precio (5.2). La vista no es un atajo que evite
--    validaciones.
--
CREATE OR REPLACE TRIGGER TRG_V_STOCK_IO
INSTEAD OF UPDATE ON V_STOCK_CONSOLIDADO
FOR EACH ROW
DECLARE
    FUNCTION cambio (p_nuevo VARCHAR2, p_viejo VARCHAR2) RETURN BOOLEAN IS
    BEGIN
        IF p_nuevo IS NULL AND p_viejo IS NULL THEN
            RETURN FALSE;
        ELSIF p_nuevo IS NULL OR p_viejo IS NULL THEN
            RETURN TRUE;
        ELSE
            RETURN p_nuevo <> p_viejo;
        END IF;
    END cambio;
BEGIN
    IF cambio(TO_CHAR(:NEW.id_producto), TO_CHAR(:OLD.id_producto))
       OR cambio(:NEW.codigo, :OLD.codigo)
       OR cambio(:NEW.producto, :OLD.producto)
       OR cambio(:NEW.categoria, :OLD.categoria)
       OR cambio(TO_CHAR(:NEW.stock_total), TO_CHAR(:OLD.stock_total)) THEN
        RAISE_APPLICATION_ERROR(-20050,
            'Por V_STOCK_CONSOLIDADO solo se modifican precio_unitario y stock_minimo. ' ||
            'El stock se ajusta con SP_AJUSTAR_STOCK.');
    END IF;

    UPDATE PRODUCTO
       SET precio_unitario = :NEW.precio_unitario,
           stock_minimo    = :NEW.stock_minimo
     WHERE id_producto = :OLD.id_producto;
END TRG_V_STOCK_IO;
/

-- EVIDENCIA 5.6
-- RESULTADO ESPERADO: HM-0001 queda en 47000 / minimo 25 y se genera 1
-- auditoria | cambiar stock_total -> -20050 | precio 30000 -> -20020 (el
-- margen de la tabla real tambien aplica por la vista).
DECLARE
    v_precio  PRODUCTO.precio_unitario%TYPE;
    v_minimo  PRODUCTO.stock_minimo%TYPE;
    v_aud     NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    UPDATE V_STOCK_CONSOLIDADO
       SET precio_unitario = 47000, stock_minimo = 25
     WHERE codigo = 'HM-0001';
    DBMS_OUTPUT.PUT_LINE('Filas de la vista actualizadas: ' || SQL%ROWCOUNT);

    SELECT precio_unitario, stock_minimo INTO v_precio, v_minimo FROM PRODUCTO WHERE codigo = 'HM-0001';
    SELECT COUNT(*) INTO v_aud FROM AUDITORIA_PRECIO WHERE id_producto = 1001;
    DBMS_OUTPUT.PUT_LINE('PRODUCTO HM-0001: precio ' || v_precio || ', stock minimo ' || v_minimo ||
                         ' | auditorias generadas: ' || v_aud);

    BEGIN
        UPDATE V_STOCK_CONSOLIDADO SET stock_total = 999 WHERE codigo = 'HM-0001';
        DBMS_OUTPUT.PUT_LINE('stock_total modificado (no deberia).');
    EXCEPTION
        WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('UPDATE de stock_total rechazado: ' || SQLERRM);
    END;

    BEGIN
        UPDATE V_STOCK_CONSOLIDADO SET precio_unitario = 30000 WHERE codigo = 'HM-0001';
        DBMS_OUTPUT.PUT_LINE('Precio bajo el margen aceptado (no deberia).');
    EXCEPTION
        WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Precio 30000 rechazado: ' || SQLERRM);
    END;
    ROLLBACK;
END;
/


--==============================================================================
-- PARTE 6 — CASO INTEGRADOR                                   (5 puntos / 45 min)
--==============================================================================

-------------------------------------------------------------------------------
-- PKG_VENTAS
-- Construya un PAQUETE que exponga el procedimiento SP_FACTURAR_PEDIDO, el cual,
-- para un pedido en estado BORRADOR, debe:
--
--   1. Validar que el pedido exista y este en BORRADOR
--   2. Recorrer sus lineas con un cursor y acumular el subtotal
--   3. Calcular el descuento con FN_CALCULAR_DESCUENTO
--   4. Validar contra FN_CUPO_DISPONIBLE que el cliente tenga cupo suficiente
--   5. Actualizar el total del pedido y cambiar su estado a CONFIRMADO
--   6. Incrementar el saldo pendiente del cliente
--   7. Usar SAVEPOINT y revertir parcialmente ante cualquier fallo, registrando
--      el error con SP_REGISTRAR_ERROR
--   8. Devolver por parametros OUT el total facturado y el descuento aplicado
--
-- Firma esperada:
--   PKG_VENTAS.SP_FACTURAR_PEDIDO(p_id_pedido IN NUMBER,
--                                 p_total     OUT NUMBER,
--                                 p_descuento OUT NUMBER)
--
-- Se evalua la integracion. El procedimiento debe apoyarse en los objetos de las
-- partes 1 a 5 y no reimplementar su logica: uno que vuelva a codificar el
-- calculo del descuento pierde la mitad del puntaje de esta parte.
-- Defina explicitamente el alcance transaccional y justifique donde decidio
-- ubicar la confirmacion de la transaccion.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- INTEGRACION (que se reutiliza y por que):
-- * FN_CALCULAR_DESCUENTO (2.3) y FN_CUPO_DISPONIBLE (2.2): las reglas de
--   descuento y de cupo viven en un solo lugar; si cambian los porcentajes, la
--   facturacion cambia sin tocar el paquete.
-- * SP_REGISTRAR_ERROR (4.5): el error queda registrado aunque se revierta.
-- * TRG_DETALLE_AI_STOCK (5.4) ya desconto el stock al insertar las lineas, y
--   TRG_DETALLE_TOTAL (5.5) mantuvo el total bruto del BORRADOR. Facturar no
--   vuelve a descontar inventario: hacerlo aqui lo descontaria dos veces.
-- * SP_CREAR_PEDIDO (1.3) y SP_ANULAR_PEDIDO (4.3) completan el ciclo en la
--   evidencia (crear -> lineas -> facturar -> anular).
--
-- ALCANCE TRANSACCIONAL Y UBICACION DEL COMMIT:
-- El procedimiento NO hace COMMIT; la confirmacion queda en quien invoca. Su
-- alcance es: desde el SAVEPOINT inicial hasta su ultima sentencia, dentro de
-- la transaccion del llamador. Razones:
-- 1) La unidad de trabajo real es "crear pedido + insertar lineas + facturar".
--    Esas lineas las inserto el llamador en la misma transaccion. Un COMMIT
--    dentro del paquete confirmaria tambien ese trabajo ajeno, y el llamador
--    perderia la posibilidad de revertir la operacion completa.
-- 2) Un COMMIT interno elimina todos los savepoints y libera los bloqueos: el
--    procedimiento dejaria de ser componible (no podria formar parte de un
--    proceso mayor, como facturar varios pedidos de forma atomica).
-- 3) El SAVEPOINT permite una reversion PARCIAL: ante un fallo se deshace solo
--    lo que hizo la facturacion (estado, total, saldo) y se conserva el trabajo
--    previo del llamador, que puede corregir (p. ej. quitar una linea) y
--    reintentar. Es necesario porque, cuando el error se captura en PL/SQL,
--    Oracle NO revierte automaticamente lo ya ejecutado dentro del
--    procedimiento; sin el savepoint podria quedar el pedido CONFIRMADO y el
--    saldo sin actualizar.
-- 4) Orden en el manejador: primero SP_REGISTRAR_ERROR (mientras SQLCODE y el
--    backtrace describen el error), luego ROLLBACK TO, luego RAISE para que el
--    llamador se entere. El log persiste porque es autonomo.
--
-- CONCURRENCIA:
-- * El pedido se bloquea (FOR UPDATE) al leerlo: dos facturaciones simultaneas
--   del mismo pedido no pueden pasar ambas la validacion de BORRADOR, ni se
--   puede anular mientras se factura.
-- * El cliente se bloquea ANTES de consultar el cupo: sin eso, dos pedidos del
--   mismo cliente facturados a la vez verian el mismo cupo libre y ambos lo
--   usarian (verificar-luego-actuar). Con el bloqueo, el segundo espera y lee
--   el saldo ya incrementado.
-- * Orden de bloqueo fijo: primero PEDIDO, luego CLIENTE, igual que
--   SP_ANULAR_PEDIDO. Un orden consistente evita el bloqueo mutuo (ORA-00060)
--   entre una facturacion y una anulacion concurrentes.
-- * WAIT 5 acota la espera; ROLLBACK TO libera los bloqueos tomados despues
--   del savepoint.
--
-- ORDEN DE NEGOCIO: el descuento se calcula ANTES de incrementar el saldo; al
-- reves, todo cliente sin deuda perderia el 2% en su propia factura. El cupo se
-- valida contra el total NETO, que es lo que realmente se le cobra.
-- El subtotal se acumula recorriendo las lineas (paso 2) y no se toma de
-- PEDIDO.total: la fuente de verdad son las lineas; la cabecera es un derivado.
--
CREATE OR REPLACE PACKAGE PKG_VENTAS IS
    -- Factura un pedido en BORRADOR. No confirma la transaccion: el COMMIT
    -- corresponde al llamador. Errores: -20060 pedido inexistente, -20061 no
    -- esta en BORRADOR, -20062 sin lineas, -20063 cupo insuficiente.
    PROCEDURE SP_FACTURAR_PEDIDO (
        p_id_pedido IN  NUMBER,
        p_total     OUT NUMBER,
        p_descuento OUT NUMBER
    );
END PKG_VENTAS;
/

CREATE OR REPLACE PACKAGE BODY PKG_VENTAS IS

    c_origen CONSTANT VARCHAR2(60) := 'PKG_VENTAS.SP_FACTURAR_PEDIDO';

    PROCEDURE SP_FACTURAR_PEDIDO (
        p_id_pedido IN  NUMBER,
        p_total     OUT NUMBER,
        p_descuento OUT NUMBER
    ) IS
        CURSOR c_lineas (pc_id_pedido DETALLE_PEDIDO.id_pedido%TYPE) IS
            SELECT linea, id_producto, cantidad, precio_unitario, subtotal
              FROM DETALLE_PEDIDO
             WHERE id_pedido = pc_id_pedido
             ORDER BY linea;

        v_id_cliente  PEDIDO.id_cliente%TYPE;
        v_estado      PEDIDO.estado%TYPE;
        v_bloqueo     CLIENTE.id_cliente%TYPE;
        v_subtotal    NUMBER := 0;
        v_lineas      PLS_INTEGER := 0;
        v_descuento   NUMBER;
        v_neto        NUMBER;
        v_cupo        NUMBER;
    BEGIN
        SAVEPOINT sp_facturar_pedido;

        -- 1. El pedido existe y esta en BORRADOR (se bloquea la fila)
        BEGIN
            SELECT id_cliente, estado
              INTO v_id_cliente, v_estado
              FROM PEDIDO
             WHERE id_pedido = p_id_pedido
               FOR UPDATE WAIT 5;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20060, 'El pedido ' || p_id_pedido || ' no existe.');
        END;

        IF v_estado <> 'BORRADOR' THEN
            RAISE_APPLICATION_ERROR(-20061, 'El pedido ' || p_id_pedido || ' esta en estado ' ||
                                    v_estado || '; solo se factura un pedido en BORRADOR.');
        END IF;

        -- 2. Recorrido de lineas con cursor y acumulacion del subtotal
        FOR r IN c_lineas(p_id_pedido) LOOP
            v_subtotal := v_subtotal + r.subtotal;
            v_lineas   := v_lineas + 1;
        END LOOP;

        IF v_lineas = 0 THEN
            RAISE_APPLICATION_ERROR(-20062, 'El pedido ' || p_id_pedido || ' no tiene lineas.');
        END IF;

        -- Bloqueo del cliente antes de decidir sobre su cupo
        SELECT id_cliente INTO v_bloqueo
          FROM CLIENTE
         WHERE id_cliente = v_id_cliente
           FOR UPDATE WAIT 5;

        -- 3. Descuento (regla de 2.3, calculada antes de tocar el saldo)
        v_descuento := FN_CALCULAR_DESCUENTO(v_id_cliente, v_subtotal);
        v_neto      := v_subtotal - v_descuento;

        -- 4. Cupo (regla de 2.2) contra el total neto
        v_cupo := FN_CUPO_DISPONIBLE(v_id_cliente);
        IF v_neto > v_cupo THEN
            RAISE_APPLICATION_ERROR(-20063,
                'Cupo insuficiente para el cliente ' || v_id_cliente || ': total a facturar ' ||
                v_neto || ', cupo disponible ' || v_cupo || '.');
        END IF;

        -- 5. Cabecera: total neto y estado CONFIRMADO
        UPDATE PEDIDO
           SET total  = v_neto,
               estado = 'CONFIRMADO'
         WHERE id_pedido = p_id_pedido;

        -- 6. Saldo pendiente del cliente
        UPDATE CLIENTE
           SET saldo_pendiente = saldo_pendiente + v_neto
         WHERE id_cliente = v_id_cliente;

        -- 8. Resultados
        p_total     := v_neto;
        p_descuento := v_descuento;
    EXCEPTION
        -- 7. Registro del error, reversion parcial y propagacion
        WHEN OTHERS THEN
            SP_REGISTRAR_ERROR(c_origen, 'id_pedido=' || p_id_pedido);
            ROLLBACK TO sp_facturar_pedido;
            RAISE;
    END SP_FACTURAR_PEDIDO;

END PKG_VENTAS;
/

-- EVIDENCIA 6-A — ciclo completo: crear, agregar lineas, facturar y anular
-- RESULTADO ESPERADO (cliente 503, sin saldo):
--   Antes:    BORRADOR, total 1105000, saldo 0, stock 1004/B1 32, 1013/B1 200
--   Factura:  subtotal 1105000, descuento 77350 (5% + 2%), total 1027650
--   Despues:  CONFIRMADO, total 1027650, saldo 1027650
--   Anulado:  ANULADO, saldo 0, stock 1004/B1 35 y 1013/B1 210 (devuelto)
DECLARE
    v_ped    NUMBER;
    v_total  NUMBER;
    v_desc   NUMBER;
    PROCEDURE estado (p_desc VARCHAR2) IS
        v_est   PEDIDO.estado%TYPE;
        v_tot   PEDIDO.total%TYPE;
        v_saldo CLIENTE.saldo_pendiente%TYPE;
    BEGIN
        SELECT p.estado, p.total, c.saldo_pendiente
          INTO v_est, v_tot, v_saldo
          FROM PEDIDO p JOIN CLIENTE c ON c.id_cliente = p.id_cliente
         WHERE p.id_pedido = v_ped;
        DBMS_OUTPUT.PUT_LINE(RPAD(p_desc, 20) || RPAD(v_est, 11) || ' total ' || LPAD(v_tot, 8) ||
                             ' | saldo 503 ' || LPAD(v_saldo, 8) ||
                             ' | stock 1004/B1 ' || FN_STOCK_DISPONIBLE(1004, 1) ||
                             ', 1013/B1 ' || FN_STOCK_DISPONIBLE(1013, 1));
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    SP_CREAR_PEDIDO(503, v_ped);
    DBMS_OUTPUT.PUT_LINE('Pedido creado: ' || v_ped);
    INSERT INTO DETALLE_PEDIDO (id_pedido, linea, id_producto, id_bodega, cantidad, precio_unitario, subtotal)
    VALUES (v_ped, 1, 1004, 1,  3, 320000, 960000);
    INSERT INTO DETALLE_PEDIDO (id_pedido, linea, id_producto, id_bodega, cantidad, precio_unitario, subtotal)
    VALUES (v_ped, 2, 1013, 1, 10,  14500, 145000);
    estado('Antes de facturar');

    PKG_VENTAS.SP_FACTURAR_PEDIDO(v_ped, v_total, v_desc);
    DBMS_OUTPUT.PUT_LINE('Facturado: descuento ' || v_desc || ', total facturado ' || v_total);
    estado('Despues facturar');

    SP_ANULAR_PEDIDO(v_ped);
    estado('Despues de anular');

    ROLLBACK;   -- evidencia repetible. En operacion, aqui el llamador hace COMMIT.
END;
/

-- EVIDENCIA 6-B — fallo por cupo: reversion parcial y registro persistente
-- RESULTADO ESPERADO (cliente 502, cupo disponible 300000): pedido de 370000
-- sin descuento -> -20063. El pedido sigue en BORRADOR con su linea (solo se
-- revirtio la facturacion). Tras el ROLLBACK final el pedido desaparece, pero
-- LOG_ERRORES conserva el registro.
DECLARE
    v_ped        NUMBER;
    v_total      NUMBER;
    v_desc       NUMBER;
    v_est        PEDIDO.estado%TYPE;
    v_tot        PEDIDO.total%TYPE;
    v_lineas     NUMBER;
    v_existe     NUMBER;
    v_log_antes  NUMBER;
    v_log_desp   NUMBER;
    v_codigo     LOG_ERRORES.codigo_error%TYPE;
    v_mensaje    LOG_ERRORES.mensaje%TYPE;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    SELECT COUNT(*) INTO v_log_antes FROM LOG_ERRORES;

    SP_CREAR_PEDIDO(502, v_ped);
    INSERT INTO DETALLE_PEDIDO (id_pedido, linea, id_producto, id_bodega, cantidad, precio_unitario, subtotal)
    VALUES (v_ped, 1, 1008, 1, 20, 18500, 370000);
    DBMS_OUTPUT.PUT_LINE('Pedido ' || v_ped || ' del cliente 502 con subtotal 370000. Cupo disponible: ' ||
                         FN_CUPO_DISPONIBLE(502));
    BEGIN
        PKG_VENTAS.SP_FACTURAR_PEDIDO(v_ped, v_total, v_desc);
        DBMS_OUTPUT.PUT_LINE('Facturado (no deberia).');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Facturacion rechazada: ' || SQLERRM);
    END;

    SELECT estado, total INTO v_est, v_tot FROM PEDIDO WHERE id_pedido = v_ped;
    SELECT COUNT(*) INTO v_lineas FROM DETALLE_PEDIDO WHERE id_pedido = v_ped;
    DBMS_OUTPUT.PUT_LINE('Tras el ROLLBACK TO SAVEPOINT: pedido en ' || v_est || ', total ' || v_tot ||
                         ', lineas ' || v_lineas || ' (el trabajo previo del llamador se conserva)');

    ROLLBACK;
    SELECT COUNT(*) INTO v_existe FROM PEDIDO WHERE id_pedido = v_ped;
    SELECT COUNT(*) INTO v_log_desp FROM LOG_ERRORES;
    SELECT codigo_error, mensaje INTO v_codigo, v_mensaje
      FROM LOG_ERRORES WHERE id_log = (SELECT MAX(id_log) FROM LOG_ERRORES);
    DBMS_OUTPUT.PUT_LINE('Tras el ROLLBACK del llamador: el pedido existe? ' ||
                         CASE WHEN v_existe = 0 THEN 'NO' ELSE 'SI' END);
    DBMS_OUTPUT.PUT_LINE('LOG_ERRORES: antes ' || v_log_antes || ', despues ' || v_log_desp ||
                         ' | ultimo: ' || v_codigo || ' ' || v_mensaje);
END;
/

-- EVIDENCIA 6-C — validaciones de estado
-- RESULTADO ESPERADO: 999 -> -20060 | 7 (ANULADO) -> -20061 | 1 (CONFIRMADO)
-- -> -20061 | pedido sin lineas -> -20062
DECLARE
    v_vacio NUMBER;
    PROCEDURE probar (p_desc VARCHAR2, p_pedido NUMBER) IS
        v_total NUMBER;
        v_desc  NUMBER;
    BEGIN
        PKG_VENTAS.SP_FACTURAR_PEDIDO(p_pedido, v_total, v_desc);
        DBMS_OUTPUT.PUT_LINE(RPAD('OK        ' || p_desc, 40) || 'total ' || v_total);
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(RPAD('RECHAZADO ' || p_desc, 40) || SQLERRM);
    END;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' ');
    probar('Pedido 999 (no existe)',  999);
    probar('Pedido 7 (ANULADO)',        7);
    probar('Pedido 1 (CONFIRMADO)',     1);
    SP_CREAR_PEDIDO(503, v_vacio);
    probar('Pedido ' || v_vacio || ' sin lineas', v_vacio);
    ROLLBACK;
END;
/


--==============================================================================
-- FIN DE LA PLANTILLA
--==============================================================================
